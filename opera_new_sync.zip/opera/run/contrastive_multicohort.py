"""
OPERA multi-cohort contrastive learning stage.

Identical to contrastive.py but uses MultiCohortContrastiveDataModule
to train across all disease cohorts simultaneously.  The DAPT-prior
cohort similarity weights handle soft cross-disease pair weighting.

Usage:
    python -m opera.run.contrastive_multicohort \\
        dapt_ckpt=/path/to/dapt/best.ckpt \\
        dapt_embedding_store=/path/to/dapt_embeddings.pt
"""

import csv

import hydra
import lightning as L
import torch
from dotenv import load_dotenv
from omegaconf import DictConfig, OmegaConf
from lightning.pytorch.loggers import CSVLogger
from lightning.pytorch.callbacks import EarlyStopping, LearningRateMonitor, ModelCheckpoint

from bonsai.functional.pathing import get_experiment_output_path
from bonsai.functional.versioning import generate_unused_run_id
from bonsai.functional.checkpointing import (
    MODEL_INIT_CONFIG_KEY,
    clean_lightning_state_dict,
    extract_encoder_state_dict,
    get_saved_encoder_config,
    resolve_resume_checkpoint,
    save_checkpoint_metadata_sidecar,
)
from bonsai.functional.checkpointing import (
    mark_training_complete,
    should_skip_completed_training,
)
from bonsai.functional.input_contract import (
    input_contract_metadata,
    resolve_numeric_value_control,
)
from opera.compat.bonsai import build_bonsai_encoder, encoder_hparams
from opera.functional.direct_cr_contract import validate_direct_cr_config
from opera.modules.networks.opera_nets import OperaContrastiveModel
from opera.modules.networks.outcome_scaling import resolve_outcome_reference_scales
from opera.modules.networks.competing_risk import (
    estimate_piecewise_null_log_hazards,
    summarize_competing_risk_support,
    validate_competing_risk_sampling,
)
from opera.modules.lightningmodules.OperaContrastiveModule import OperaContrastiveModule
from opera.modules.datamodules.MultiCohortContrastiveDataModule import (
    MultiCohortContrastiveDataModule,
    compute_pooled_event_time_probability_grids,
)

load_dotenv()
OmegaConf.register_new_resolver(
    "version", lambda: generate_unused_run_id(), use_cache=True, replace=True
)
# These are deliberately kept in the contrastive entry point rather than only
# in the config generator.  A generated YAML file is easy to edit by hand;
# this guard makes it impossible to accidentally route a held-out transfer
# target back into the loss, validation data module, or checkpoint selection.
_TRANSFER_METADATA_FIELDS = (
    "condition",
    "transfer_level",
    "seed",
    "included_outcomes",
    "excluded_outcomes",
    "evaluation_outcomes",
    "related_retained_outcomes",
    "direct_dependencies_excluded",
    "registry_hash",
    "manifest_hash",
    "base_contrastive_config_hash",
    "split_contract",
    "split_contract_hash",
    "source_dapt_checkpoint",
    "selection_outcomes",
)


def _initialize_source_adapters(model, source_path: str, outcome_names: list[str]) -> None:
    """Load every shared BCE tensor, allowing only new adapter/router tensors."""
    source = torch.load(source_path, map_location="cpu", weights_only=False)
    init = source.get("hyper_parameters", {}).get(MODEL_INIT_CONFIG_KEY, {})
    risk = dict(init.get("competing_risk_config", {}))
    if risk.get("objective") != "horizon_bce" or risk.get("readout_mode", "shared") != "shared":
        raise ValueError("Adapter initialization requires a shared horizon-BCE checkpoint")
    state = clean_lightning_state_dict(source["state_dict"])
    if "competing_risk_head.weight" not in state:
        raise ValueError("Source checkpoint has no shared competing-risk head")
    if state["competing_risk_head.weight"].shape != model.competing_risk_head.weight.shape:
        raise ValueError("Source head shape does not match the configured outcome panel")
    if tuple(init.get("cohort_names", [])) != tuple(model.model_init_config["cohort_names"]):
        raise ValueError("Source checkpoint cohort order does not match")
    if tuple(source.get("hyper_parameters", {}).get("outcome_names", outcome_names)) != tuple(outcome_names):
        raise ValueError("Source checkpoint outcome order does not match")
    missing, unexpected = model.load_state_dict(state, strict=False)
    expected = {key for key in model.state_dict() if key.startswith("source_adapter_readout.")}
    if set(missing) != expected or unexpected:
        raise RuntimeError(
            f"Source initialization mismatch: missing={sorted(set(missing)-expected)}, "
            f"unexpected={unexpected}"
        )


def _set_source_training_support(model, train_dataset, output_path: str, event_tau: float) -> None:
    """Count source support from eligible training records only."""
    readout = model.source_adapter_readout
    patients = [set() for _ in range(readout.n_sources)]
    events = [0] * readout.n_sources
    observations = [0] * readout.n_sources
    datasets = getattr(train_dataset, "datasets", [train_dataset])
    for dataset in datasets:
        fine_map = dataset.fine_index_by_subject or {}
        for outcome, records in dataset.outcome_dicts.items():
            outcome_source = readout.n_disease + readout.outcome_names.index(outcome)
            for subject_id, record in records.items():
                if int(record.get("event", -1)) < 0 or float(record.get("time_days", -1)) < 0:
                    continue
                disease_source = fine_map.get(subject_id, -1)
                for source in (outcome_source, disease_source):
                    if source < 0:
                        continue
                    patients[source].add(subject_id)
                    observations[source] += 1
                    events[source] += int(record["event"] == 1)
    readout.set_training_support(
        [len(group) for group in patients], events, observations, event_tau=event_tau
    )
    names = [*("disease:" + n for n in readout.fine_names),
             *("outcome:" + n for n in readout.outcome_names)]
    with open(output_path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["source_index", "source_name", "training_patients", "training_events", "eligible_observations", "shrinkage"])
        for i, name in enumerate(names):
            writer.writerow([i, name, len(patients[i]), events[i], observations[i], float(readout.source_shrinkage[i])])


def _uses_gradient_cache(
    *,
    batch_size: int,
    logical_batch_size: int | None,
) -> bool:
    """Return whether logical batches are actually split into microbatches."""
    if logical_batch_size is None:
        return False
    return int(logical_batch_size) > int(batch_size)


def _validate_transfer_config(cfg: DictConfig, outcome_names: list[str]) -> dict | None:
    """Validate the narrow outcome-transfer training contract at launch.

    The outcome mapping is the only source passed into the contrastive data
    module below.  For transfer ablations, require it to be exactly the
    explicit included panel and require checkpoint selection to use that same
    panel.  Evaluation labels are intentionally *not* loaded in this process;
    they are consumed later by the frozen-probe evaluator.
    """
    if not bool(cfg.get("transfer_analysis", False)):
        return None

    if bool(cfg.get("launch_blocked", False)):
        raise ValueError(
            "This outcome-transfer condition is blocked: "
            f"{cfg.get('launch_blocked_reason', 'no reason recorded')}"
        )

    condition = cfg.get("transfer_condition")
    if not isinstance(condition, str) or not condition:
        raise ValueError("Transfer config requires a non-empty transfer_condition.")

    included = list(cfg.get("training_outcomes", []))
    excluded = list(cfg.get("training_excluded_outcomes", []))
    selection = list(cfg.get("selection_outcomes", []))
    if not included:
        raise ValueError("Transfer config requires non-empty training_outcomes.")
    overlap = sorted(set(excluded) & set(outcome_names))
    if overlap:
        raise ValueError(
            f"Held-out transfer labels cannot enter contrastive adaptation: {overlap}."
        )
    # The existing contrastive model sorts its internal head names while the
    # generated YAML preserves canonical registry order.  The leakage
    # contract is membership-based, not an incidental dict-order contract.
    if set(outcome_names) != set(included) or len(outcome_names) != len(included):
        raise ValueError(
            "Transfer config outcome mapping must contain exactly training_outcomes; "
            f"mapping={outcome_names}, training_outcomes={included}."
        )
    if selection != included:
        raise ValueError(
            "Transfer checkpoint selection must use exactly training_outcomes; "
            f"selection_outcomes={selection}, training_outcomes={included}."
        )
    if len(set(included)) != len(included) or len(set(excluded)) != len(excluded):
        raise ValueError("Transfer outcome lists cannot contain duplicates.")

    seed = cfg.get("seed")
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise ValueError("Transfer contrastive runs require an integer top-level seed.")
    permitted_seeds = list(cfg.get("transfer_seeds", []))
    if permitted_seeds and seed not in permitted_seeds:
        raise ValueError(
            f"Seed {seed} is not declared by transfer_seeds={permitted_seeds}."
        )

    declared = OmegaConf.to_container(
        # Do not resolve unrelated environment interpolations here.  This
        # guard executes before DAPT I/O and should report an outcome-panel
        # breach even in a config-only dry run without server paths exported.
        cfg.get("transfer_checkpoint_metadata", {}),
        resolve=False,
    )
    if not isinstance(declared, dict):
        raise ValueError("transfer_checkpoint_metadata must be a mapping.")
    missing = [field for field in _TRANSFER_METADATA_FIELDS if field not in declared]
    # ``seed`` is populated at runtime below, so it is the one allowed omission
    # in the deterministic condition-level YAML.
    missing = [field for field in missing if field != "seed"]
    if missing:
        raise ValueError(
            f"Transfer checkpoint metadata is incomplete; missing {sorted(missing)}."
        )
    for key, expected in {
        "condition": condition,
        "included_outcomes": included,
        "excluded_outcomes": excluded,
        "selection_outcomes": included,
        "base_contrastive_config_hash": cfg.get("base_contrastive_config_hash"),
        "split_contract_hash": cfg.get("split_contract_hash"),
    }.items():
        if key in declared and declared[key] != expected:
            raise ValueError(
                f"Transfer metadata field {key!r} disagrees with launch config."
            )
    return declared


def _checkpoint_metadata(
    cfg: DictConfig,
    outcome_names: list[str],
    transfer_metadata: dict | None,
    numeric_value_control: str,
) -> dict:
    """Build inspectable checkpoint provenance for standard and transfer runs."""
    metadata = {
        "training_stage": "opera_contrastive_adaptation",
        "source_checkpoint": str(cfg.dapt_ckpt),
        "cohort_set": sorted(cfg.cohorts.keys()),
        "outcome_set": outcome_names,
        **input_contract_metadata(numeric_value_control),
    }
    if cfg.get("source_opera_ckpt") is not None:
        metadata["source_opera_checkpoint"] = str(cfg.source_opera_ckpt)
    if transfer_metadata is None:
        return metadata
    # Copy the condition-level metadata and add the actual runtime seed.  This
    # makes the sidecar and Lightning checkpoint self-describing even when the
    # launcher supplied ``seed=...`` as a Hydra override.
    metadata.update(transfer_metadata)
    metadata.update(
        {
            "condition": str(cfg.transfer_condition),
            "transfer_level": str(cfg.transfer_level),
            "seed": int(cfg.seed),
            "included_outcomes": list(cfg.training_outcomes),
            "excluded_outcomes": list(cfg.training_excluded_outcomes),
            "evaluation_outcomes": list(cfg.evaluation_outcomes),
            "related_retained_outcomes": list(cfg.related_retained_outcomes),
            "direct_dependencies_excluded": list(cfg.direct_dependencies_excluded),
            "registry_hash": str(cfg.registry_hash),
            "manifest_hash": str(cfg.manifest_hash),
            "base_contrastive_config_hash": str(cfg.base_contrastive_config_hash),
            "split_contract": str(cfg.split_contract),
            "split_contract_hash": str(cfg.split_contract_hash),
            "source_dapt_checkpoint": str(cfg.dapt_ckpt),
            "selection_outcomes": list(cfg.selection_outcomes),
        }
    )
    return metadata


@hydra.main(
    config_path="../configs",
    config_name="generated/joint_opera_full_panel",
    version_base="1.2",
)
def main(cfg: DictConfig) -> None:
    # Transfer conditions are run once per declared seed.  Existing production
    # configs have no top-level seed, so leave their stochastic behaviour
    # unchanged unless a seed was explicitly supplied.
    if cfg.get("seed") is not None:
        L.seed_everything(int(cfg.seed), workers=True)

    # Validate the outcome panel before creating a logger, opening a DAPT
    # checkpoint, calculating event-time grids, or constructing a data module.
    # This is deliberately the earliest point at which transfer config fields
    # can be inspected, so a hand-edited YAML cannot make a held-out label
    # influence any training or checkpoint-selection operation.
    outcome_configs = OmegaConf.to_container(cfg.outcomes, resolve=True)
    outcome_names = sorted(outcome_configs.keys())
    validate_direct_cr_config(OmegaConf.to_container(cfg, resolve=True))
    validate_competing_risk_sampling(
        OmegaConf.to_container(cfg.get("competing_risk", {}), resolve=True),
        OmegaConf.to_container(
            cfg.training.get("batch_sampling", {}),
            resolve=True,
        ),
    )
    transfer_metadata = _validate_transfer_config(cfg, outcome_names)

    logger = CSVLogger(
        get_experiment_output_path(), name="contrastive_multicohort_runs"
    )
    model_save_dir = get_experiment_output_path()
    if should_skip_completed_training(model_save_dir, cfg):
        return

    # ── Load encoder from DAPT checkpoint ─────────────────────────────
    ckpt = torch.load(cfg.dapt_ckpt, map_location="cpu", weights_only=False)
    pretrain_hparams = ckpt["hyper_parameters"]
    numeric_value_control = resolve_numeric_value_control(
        cfg.training.get("numeric_value_control", "inherit"), pretrain_hparams
    )

    vocab = torch.load(cfg.paths.vocabulary, weights_only=False)

    model_cfg = get_saved_encoder_config(pretrain_hparams)
    encoder = build_bonsai_encoder(model_cfg, vocab_size=len(vocab))
    encoder_state = extract_encoder_state_dict(ckpt["state_dict"])
    encoder.load_state_dict(encoder_state, strict=True)

    # ── DAPT-prior embedding store (optional) ─────────────────────────
    dapt_embedding_store = None
    if cfg.get("dapt_embedding_store") is not None:
        print(f"Loading DAPT embedding store from {cfg.dapt_embedding_store} ...")
        dapt_embedding_store = torch.load(cfg.dapt_embedding_store, map_location="cpu")
        print(f"  Loaded {len(dapt_embedding_store)} patient embeddings.")
    elif bool(cfg.training.get("require_dapt_embedding_store", False)):
        raise ValueError(
            "training.require_dapt_embedding_store=true but "
            "dapt_embedding_store is null. Build the store with "
            "python -m opera.run.build_dapt_embedding_store before training."
        )

    # ── Build model ────────────────────────────────────────────────────
    cohort_configs = OmegaConf.to_container(cfg.cohorts, resolve=True)
    require_all_configured_cells = cfg.training.get(
        "require_all_configured_cells", True
    )
    outcome_sorted_event_times, outcome_event_time_probs = (
        compute_pooled_event_time_probability_grids(
            cohort_configs,
            outcome_configs,
            split="train",
            require_all_configured_cells=require_all_configured_cells,
        )
    )
    print(
        f"KM event-time grids computed for {len(outcome_sorted_event_times)} outcomes."
    )
    for name, t in outcome_sorted_event_times.items():
        print(f"  {name}: {len(t)} pooled KM-weighted training event locations")

    cross_outcome_config = OmegaConf.to_container(
        cfg.get("cross_outcome", {}), resolve=True
    )
    cross_outcome_config = resolve_outcome_reference_scales(cross_outcome_config)
    competing_risk_config = OmegaConf.to_container(
        cfg.get("competing_risk", {}), resolve=True
    )
    # Curriculum is a direct competing-risk training policy. Keep the public
    # config under competing_risk while passing it through the loss's shared
    # outcome-aggregation settings.
    cross_outcome_config["curriculum"] = dict(
        competing_risk_config.get("curriculum", {})
    )
    if (
        cross_outcome_config.get("aggregation") == "hierarchical_support"
        or bool(cross_outcome_config["curriculum"].get("enabled", False))
    ):
        cross_outcome_config["event_location_counts"] = {
            name: int(times.numel())
            for name, times in outcome_sorted_event_times.items()
        }

    model = OperaContrastiveModel(
        encoder=encoder,
        outcome_names=outcome_names,
        hidden_size=model_cfg["hidden_size"],
        projection_hidden_dim=cfg.model.projection_hidden_dim,
        projection_dim=cfg.model.projection_dim,
        temperature=cfg.model.temperature,
        km_time_scale=cfg.model.get("km_time_scale", 0.25),
        outcome_sorted_event_times=outcome_sorted_event_times,
        outcome_event_time_probs=outcome_event_time_probs,
        dapt_lambda_floor=cfg.model.get("dapt_lambda_floor", 0.55),
        dapt_anchor_weight=cfg.model.get("dapt_anchor_weight", 0.2),
        competing_event_weight=cfg.model.get("competing_event_weight", 0.0),
        competing_event_handling=cfg.model.get(
            "competing_event_handling", "hard_negative"
        ),
        effective_pair_normalization=cfg.model.get(
            "effective_pair_normalization", True
        ),
        cross_outcome_config=cross_outcome_config,
        projection_mode=cfg.model.get("projection_mode", "shared"),
        freeze_encoder=cfg.model.freeze_encoder,
        pooling=cfg.model.pooling,
        dapt_embedding_store=dapt_embedding_store,
        competing_risk_config=OmegaConf.to_container(
            cfg.get("competing_risk", {}),
            resolve=True,
        ),
        cohort_names=sorted(str(name) for name in cohort_configs),
    )

    # ── Data ───────────────────────────────────────────────────────────
    data_module = MultiCohortContrastiveDataModule(
        cohort_configs=cohort_configs,
        outcome_configs=outcome_configs,
        predict_token_id=vocab["[CLS]"],
        batch_size=cfg.training.batch_size,
        num_workers=cfg.hardware.num_workers,
        require_all_configured_cells=require_all_configured_cells,
        require_min_followup_train=cfg.training.get(
            "require_min_followup_train", False
        ),
        max_len=encoder_hparams(encoder)["max_seqlen"],
        batch_sampling=cfg.training.get("batch_sampling", {}),
        logical_batch_size=cfg.training.get("logical_batch_size"),
        logical_val_batch_size=cfg.training.get("logical_val_batch_size"),
        numeric_value_control=numeric_value_control,
        fine_names=competing_risk_config.get("fine_names") if model.source_adapter_readout is not None else None,
        fine_column=str(competing_risk_config.get("fine_column", "cohort_fine")),
    )
    data_module.setup("fit")

    if model.source_adapter_readout is not None:
        _initialize_source_adapters(model, str(cfg.source_opera_ckpt), outcome_names)
        _set_source_training_support(
            model, data_module.train_dataset,
            f"{model_save_dir}/source_training_support.csv",
            float(competing_risk_config.get("adapter_event_tau", 20.0)),
        )
        print(f"Initialized source adapters from {cfg.source_opera_ckpt}")

    if float(competing_risk_config.get("loss_weight", 0.0)) > 0:
        support = summarize_competing_risk_support(
            data_module.train_dataset,
            outcome_names,
            competing_risk_config["interval_boundaries_days"],
        )
        support_path = f"{model_save_dir}/competing_risk_interval_support.csv"
        with open(support_path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(support[0]))
            writer.writeheader()
            writer.writerows(support)
        sparse = [
            row
            for row in support
            if row["n_valid"] > 0 and row["n_target"] + row["n_death"] < 5
        ]
        print(
            f"Competing-risk interval support written to {support_path}; "
            f"{len(sparse)} outcome-intervals have fewer than five observed events."
        )
        needs_null_hazards = (
            str(competing_risk_config.get("weighter", "uniform")).lower()
            == "kendall_null"
            or bool(competing_risk_config.get("initialize_from_null_hazards", False))
        )
        if needs_null_hazards:
            null_log_hazards = estimate_piecewise_null_log_hazards(
                data_module.train_dataset,
                outcome_names,
                competing_risk_config["interval_boundaries_days"],
                no_competing_outcomes=competing_risk_config.get(
                    "no_competing_outcomes", ["overall_survival"]
                ),
                time_scale_days=float(
                    competing_risk_config.get("time_scale_days", 365.25)
                ),
                event_pseudocount=float(
                    competing_risk_config.get("initialization_event_pseudocount", 0.0)
                ),
            )
            if (
                str(competing_risk_config.get("weighter", "uniform")).lower()
                == "kendall_null"
            ):
                model.competing_risk_loss.set_null_log_hazards(null_log_hazards)
            if model.source_adapter_readout is None and bool(
                competing_risk_config.get("initialize_from_null_hazards", False)
            ):
                model.initialize_competing_risk_biases(null_log_hazards)
                print("Initialized direct-risk head biases from training hazards.")
            null_path = f"{model_save_dir}/competing_risk_null_log_hazards.csv"
            with open(null_path, "w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=["outcome", "cause", "interval", "log_hazard"],
                )
                writer.writeheader()
                for outcome, causes in null_log_hazards.items():
                    for cause, values in enumerate(causes):
                        for interval, value in enumerate(values):
                            writer.writerow(
                                {
                                    "outcome": outcome,
                                    "cause": cause,
                                    "interval": interval,
                                    "log_hazard": value,
                                }
                            )
            print(f"Training-only null hazards written to {null_path}.")

    if dapt_embedding_store is not None:
        datasets = getattr(
            data_module.train_dataset,
            "datasets",
            [data_module.train_dataset],
        )
        training_subjects = {
            int(subject["subject_id"])
            for dataset in datasets
            for subject in dataset.subjects
        }
        covered = training_subjects.intersection(
            int(subject_id) for subject_id in dapt_embedding_store
        )
        coverage = len(covered) / max(len(training_subjects), 1)
        print(f"DAPT embedding-store training coverage: {coverage:.2%}")
        if (
            bool(cfg.training.get("require_dapt_embedding_store", False))
            and coverage < 0.99
        ):
            raise ValueError(
                "DAPT embedding-store coverage is below 99% for the OPERA "
                f"training population ({coverage:.2%}). Rebuild the store from "
                "the same resolved joint OPERA configuration."
            )

    # ── Lightning ──────────────────────────────────────────────────────
    lightning_module = OperaContrastiveModule(
        model=model,
        outcome_names=outcome_names,
        learning_rate=cfg.training.learning_rate,
        encoder_lr_multiplier=cfg.training.encoder_lr_multiplier,
        optimizer_epsilon=cfg.training.optimizer_epsilon,
        scheduler_warmup_epochs=cfg.training.scheduler_warmup_epochs,
        dapt_anchor_weight=cfg.model.get("dapt_anchor_weight", 0.2),
        gradient_cache=_uses_gradient_cache(
            batch_size=cfg.training.batch_size,
            logical_batch_size=cfg.training.get("logical_batch_size"),
        ),
        probe_every_n_epochs=cfg.training.get("probe_every_n_epochs", 1),
        enable_validation_probe=cfg.training.get("enable_validation_probe", True),
        log_per_outcome_metrics=cfg.training.get("log_per_outcome_metrics", True),
        evaluation_horizons_days=cfg.training.get(
            "evaluation_horizons_days",
            competing_risk_config.get("interval_boundaries_days", []),
        ),
        outcome_families=cross_outcome_config.get("outcome_families", {}),
        endpoint_groups=cross_outcome_config.get("endpoint_groups", {}),
        selection_min_cases=cfg.training.get("selection_min_cases", 20),
        selection_min_controls=cfg.training.get("selection_min_controls", 20),
        checkpoint_metadata=_checkpoint_metadata(
            cfg,
            outcome_names,
            transfer_metadata,
            numeric_value_control,
        ),
    )

    monitor = str(cfg.training.get("eval_monitor_metric", "val/loss"))
    monitor_mode = "max" if "auc" in monitor.lower() else "min"
    ckpt_callback = ModelCheckpoint(
        dirpath=model_save_dir,
        monitor=monitor,
        mode=monitor_mode,
        save_top_k=1,
        filename="best",
        enable_version_counter=False,
        save_last=True,
    )

    callbacks = [ckpt_callback, LearningRateMonitor(logging_interval="step")]
    if cfg.training.get("early_stopping_patience"):
        callbacks.append(
            EarlyStopping(
                monitor=monitor,
                patience=int(cfg.training.early_stopping_patience),
                mode=monitor_mode,
            )
        )

    trainer = L.Trainer(
        default_root_dir=model_save_dir,
        accelerator=cfg.hardware.accelerator,
        accumulate_grad_batches=(
            1
            if cfg.training.get("logical_batch_size") is not None
            else cfg.training.accumulate_grad_batches
        ),
        devices=cfg.hardware.num_devices,
        limit_val_batches=cfg.training.limit_val_batches,
        limit_train_batches=cfg.training.limit_train_batches,
        callbacks=callbacks,
        logger=[logger],
        max_epochs=cfg.training.epochs,
        num_nodes=cfg.hardware.num_nodes,
        precision=cfg.hardware.precision,
        log_every_n_steps=int(cfg.training.get("log_every_n_steps", 10)),
    )

    resume_checkpoint = resolve_resume_checkpoint(
        model_save_dir,
        cfg.paths.get("resume_ckpt"),
        auto_resume=bool(cfg.training.get("auto_resume", False)),
    )
    trainer.fit(
        model=lightning_module,
        datamodule=data_module,
        ckpt_path=resume_checkpoint,
    )
    save_checkpoint_metadata_sidecar(model_save_dir, lightning_module)
    mark_training_complete(model_save_dir, cfg)


if __name__ == "__main__":
    main()
