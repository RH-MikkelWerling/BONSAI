"""
Lightning module for the OPERA contrastive learning stage.

Handles:
  - Multi-outcome survival-informed contrastive training with Kendall sigma weighting
  - Logging of per-outcome losses, sigma values, precision terms, and valid-pair counts
  - Separate param groups for encoder vs projection head (different LR)
"""

import logging
import lightning as L
import torch
from torch import nn
from torch.optim import AdamW
from typing import Dict, List, Mapping
import numpy as np
from bonsai.functional.checkpointing import (
    MODEL_INIT_CONFIG_KEY,
    attach_checkpoint_metadata,
    attach_model_config,
)
from bonsai.functional.scheduling import optimizer_with_warmup
from opera.evaluation.metrics import compute_competing_risk_metrics_at_horizon
from opera.modules.networks.competing_risk import piecewise_exponential_cif

LOGGER = logging.getLogger(__name__)


class OperaContrastiveModule(L.LightningModule):
    def __init__(
        self,
        model: nn.Module,
        outcome_names: List[str],
        learning_rate: float = 1e-4,
        encoder_lr_multiplier: float = 0.1,
        optimizer_epsilon: float = 1e-6,
        scheduler_warmup_epochs: int = 1,
        dapt_anchor_weight: float = 0.2,
        gradient_cache: bool = False,
        probe_every_n_epochs: int = 1,
        enable_validation_probe: bool = True,
        log_per_outcome_metrics: bool = True,
        evaluation_horizons_days: List[float] = None,
        outcome_families: Mapping[str, List[str]] = None,
        endpoint_groups: Mapping[str, List[str]] = None,
        selection_min_cases: int = 20,
        selection_min_controls: int = 20,
        checkpoint_metadata: dict = None,
    ):
        super().__init__()
        self.model = model
        self.dapt_anchor_weight = dapt_anchor_weight
        if hasattr(self.model, "dapt_anchor_weight"):
            self.model.dapt_anchor_weight = dapt_anchor_weight
        elif dapt_anchor_weight != 0.0:
            LOGGER.warning(
                "dapt_anchor_weight=%s was requested but the model does not "
                "expose a dapt_anchor_weight attribute; anchor loss is disabled.",
                dapt_anchor_weight,
            )
        self.save_hyperparameters(ignore=["model"])
        attach_model_config(self, model)
        if hasattr(model, "model_init_config"):
            self.hparams[MODEL_INIT_CONFIG_KEY] = dict(model.model_init_config)
        attach_checkpoint_metadata(self, checkpoint_metadata)
        self.outcome_names = outcome_names
        self.learning_rate = learning_rate
        self.encoder_lr_multiplier = encoder_lr_multiplier
        self.optimizer_epsilon = optimizer_epsilon
        self.scheduler_warmup_epochs = scheduler_warmup_epochs
        self.gradient_cache = bool(gradient_cache)
        self.probe_every_n_epochs = max(1, int(probe_every_n_epochs))
        self.enable_validation_probe = bool(enable_validation_probe)
        self.log_per_outcome_metrics = bool(log_per_outcome_metrics)
        self.evaluation_horizons_days = [
            float(value) for value in (evaluation_horizons_days or [])
        ]
        self.outcome_family = {
            outcome: family
            for family, members in dict(outcome_families or {}).items()
            for outcome in members
        }
        self._val_cr_predictions = {}
        self.endpoint_groups = dict(endpoint_groups or {})
        self.selection_min_cases = int(selection_min_cases)
        self.selection_min_controls = int(selection_min_controls)
        if self.gradient_cache:
            self.automatic_optimization = False

    def transfer_batch_to_device(self, batch, device, dataloader_idx):
        # Logical batches are lists of independently padded CPU microbatches.
        # Moving the complete list here would defeat gradient caching's memory bound.
        if self.gradient_cache and isinstance(batch, list):
            return batch
        return super().transfer_batch_to_device(batch, device, dataloader_idx)

    def _to_device(self, value):
        if isinstance(value, torch.Tensor):
            return value.to(self.device, non_blocking=True)
        if isinstance(value, dict):
            return {key: self._to_device(item) for key, item in value.items()}
        return value

    def _should_log_metric(self, key: str) -> bool:
        if key.startswith("_"):
            return False
        if self.log_per_outcome_metrics:
            return True
        detailed_prefixes = (
            "loss/",
            "loss_sigma_input/",
            "target_entropy/",
            "excess_loss/",
            "contrastive_headroom/",
            "n_valid/",
            "n_effective_pairs/",
            "effective_pair_fraction/",
            "class_balance_factor/",
            "support_weight/",
            "cross_outcome_weight/",
            "sigma/",
            "precision/",
            "cr/loss/",
            "cr/n_valid/",
            "cr/n_target/",
            "cr/n_death/",
            "cr/smoothness/",
            "cr/null_loss/",
            "cr/loss_over_null/",
            "cr/outcome_weight/",
            "cr/log_sigma/",
            "cr/horizon_bce/",
            "cr/route_source/",
        )
        return not key.startswith(detailed_prefixes)

    def _cached_training_step(self, microbatches: list[dict]) -> torch.Tensor:
        """Exact logical-batch gradient using memory-sized encoder passes."""
        optimizer = self.optimizers()
        if self.model.competing_risk_loss is not None:
            self.model.competing_risk_loss.set_curriculum_state(
                self.current_epoch, training=True
            )
        optimizer.zero_grad()
        self.model.eval()  # both encoder passes must describe the same network
        pooled_parts = []
        survival_parts = {
            name: {"times": [], "events": []} for name in self.outcome_names
        }
        subject_parts = []
        fine_parts = []
        with torch.no_grad():
            for cpu_batch in microbatches:
                batch = self._to_device(cpu_batch)
                pooled_parts.append(self.model.get_objective_representations(batch))
                survival = self._build_outcome_survival(batch)
                for name in self.outcome_names:
                    if name in survival:
                        survival_parts[name]["times"].append(survival[name]["times"])
                        survival_parts[name]["events"].append(survival[name]["events"])
                subject_parts.append(batch["subject_id"])
                if self.model.source_adapter_readout is not None:
                    fine_parts.append(batch["cohort_fine_index"])
        pooled = torch.cat(pooled_parts).detach().requires_grad_(True)
        outcome_survival = {
            name: {key: torch.cat(parts) for key, parts in fields.items()}
            for name, fields in survival_parts.items()
            if fields["times"]
        }
        result = self.model.forward_from_pooled(
            pooled, outcome_survival, torch.cat(subject_parts),
            torch.cat(fine_parts) if fine_parts else None,
        )
        loss = result["loss"]
        self.manual_backward(loss)
        if not self.model.freeze_encoder:
            pooled_grad = pooled.grad.detach()
            offset = 0
            for cpu_batch in microbatches:
                batch = self._to_device(cpu_batch)
                recomputed = self.model.get_objective_representations(batch)
                count = recomputed.shape[0]
                self.manual_backward(
                    (recomputed * pooled_grad[offset : offset + count]).sum()
                )
                offset += count
        optimizer.step()
        scheduler = self.lr_schedulers()
        if scheduler is not None:
            # Gradient caching uses manual optimization, so Lightning does not
            # advance an interval="step" scheduler for us.
            scheduler.step()
        logical_size = len(pooled)
        self.log(
            "train/loss",
            loss.detach(),
            prog_bar=True,
            on_step=True,
            on_epoch=True,
            batch_size=logical_size,
        )
        self.log(
            "train/logical_batch_size",
            float(logical_size),
            on_step=True,
            on_epoch=True,
            batch_size=logical_size,
        )
        auxiliary_metrics = {
            f"train/{key}": value
            for key, value in result.items()
            if key != "loss" and self._should_log_metric(key)
        }
        self.log_dict(
            auxiliary_metrics,
            on_step=True,
            on_epoch=True,
            batch_size=logical_size,
        )
        return loss.detach()

    def _build_outcome_survival(
        self, batch: dict
    ) -> Dict[str, Dict[str, torch.Tensor]]:
        """
        Collect per-outcome survival dicts from the batch.

        Looks for ``time_<name>`` and ``event_<name>`` tensors.
        Falls back gracefully if only binary ``outcome_<name>`` is present
        (treats label as event indicator, time = -1 → missing → pair skipped).
        """
        outcome_survival = {}
        for name in self.outcome_names:
            time_key = f"time_{name}"
            event_key = f"event_{name}"
            label_key = f"outcome_{name}"

            if time_key in batch and event_key in batch:
                outcome_survival[name] = {
                    "times": batch[time_key],
                    "events": batch[event_key],
                }
            elif label_key in batch:
                # Fallback: binary label only — treat as event, time unknown
                labels = batch[label_key]
                outcome_survival[name] = {
                    "times": torch.full_like(labels, -1, dtype=torch.float),
                    "events": labels,
                }
        return outcome_survival

    def _shared_step(self, batch: dict, prefix: str) -> torch.Tensor:
        if self.model.competing_risk_loss is not None:
            self.model.competing_risk_loss.set_curriculum_state(
                self.current_epoch, training=prefix == "train"
            )
        outcome_survival = self._build_outcome_survival(batch)
        log_dict = self.model(batch, outcome_survival)
        loss = log_dict["loss"]
        if prefix == "val":
            self._accumulate_competing_risk_validation(
                log_dict.get("_competing_risk_log_hazards"), outcome_survival
            )

        self.log(f"{prefix}/loss", loss, prog_bar=True)
        for k, v in log_dict.items():
            if k != "loss" and self._should_log_metric(k):
                self.log(f"{prefix}/{k}", v)

        return loss

    def training_step(self, batch, batch_idx):
        if self.gradient_cache:
            if not isinstance(batch, list):
                raise TypeError(
                    "Gradient caching requires a list of microbatch dictionaries. "
                    "Set logical_batch_size greater than batch_size, or disable "
                    "gradient caching when both sizes are equal."
                )
            return self._cached_training_step(batch)
        return self._shared_step(batch, "train")

    def validation_step(self, batch, batch_idx):
        if self.model.competing_risk_loss is not None:
            self.model.competing_risk_loss.set_curriculum_state(
                self.current_epoch, training=False
            )
        if self.gradient_cache and isinstance(batch, list):
            pooled_parts, subject_parts = [], []
            survival_parts = {
                name: {"times": [], "events": []} for name in self.outcome_names
            }
            fine_parts = []
            with torch.no_grad():
                for cpu_batch in batch:
                    microbatch = self._to_device(cpu_batch)
                    pooled_parts.append(
                        self.model.get_objective_representations(microbatch)
                    )
                    survival = self._build_outcome_survival(microbatch)
                    for name, fields in survival.items():
                        survival_parts[name]["times"].append(fields["times"])
                        survival_parts[name]["events"].append(fields["events"])
                    subject_parts.append(microbatch["subject_id"])
                    if self.model.source_adapter_readout is not None:
                        fine_parts.append(microbatch["cohort_fine_index"])
                pooled = torch.cat(pooled_parts)
                result = self.model.forward_from_pooled(
                    pooled,
                    {
                        name: {key: torch.cat(values) for key, values in fields.items()}
                        for name, fields in survival_parts.items()
                        if fields["times"]
                    },
                    torch.cat(subject_parts),
                    torch.cat(fine_parts) if fine_parts else None,
                )
            self._accumulate_competing_risk_validation(
                result.get("_competing_risk_log_hazards"),
                {
                    name: {key: torch.cat(values) for key, values in fields.items()}
                    for name, fields in survival_parts.items()
                    if fields["times"]
                },
            )
            self.log("val/loss", result["loss"], prog_bar=True, batch_size=len(pooled))
            for key, value in result.items():
                if key != "loss" and self._should_log_metric(key):
                    self.log(f"val/{key}", value, batch_size=len(pooled))
            if not self.enable_validation_probe:
                return result["loss"]
            if not hasattr(self, "_val_probe_emb_store"):
                self._val_probe_embs = {name: [] for name in self.outcome_names}
                self._val_probe_labels = {name: [] for name in self.outcome_names}
                self._val_probe_emb_store = []
            if pooled.ndim != 2:
                raise ValueError(
                    "Validation probes require shared patient representations; "
                    "disable them for outcome-attention experiments."
                )
            self._val_probe_emb_store.append(self.model.projection(pooled).detach().cpu())
            for name in self.outcome_names:
                key = f"outcome_{name}"
                labels = [micro[key].detach().cpu() for micro in batch if key in micro]
                if labels:
                    self._val_probe_labels[name].append(torch.cat(labels))
            return result["loss"]
        loss = self._shared_step(batch, "val")

        if not self.enable_validation_probe:
            return loss

        # Accumulate embeddings + labels for end-of-epoch linear probe
        with torch.no_grad():
            emb = self.model.get_embeddings(batch).cpu()

        if not hasattr(self, "_val_probe_embs"):
            self._val_probe_embs: Dict[str, list] = {n: [] for n in self.outcome_names}
            self._val_probe_labels: Dict[str, list] = {
                n: [] for n in self.outcome_names
            }
            self._val_probe_emb_store: list = []

        self._val_probe_emb_store.append(emb)
        for name in self.outcome_names:
            label_key = f"outcome_{name}"
            if label_key in batch:
                self._val_probe_labels[name].append(batch[label_key].cpu())

        return loss

    def _accumulate_competing_risk_validation(
        self, log_hazards, outcome_survival
    ) -> None:
        """Collect direct-head CIFs and labels for full-validation metrics."""
        objective = getattr(self.model, "competing_risk_loss", None)
        if log_hazards is None or objective is None:
            return
        # Specialist all-horizon finetuning deliberately keeps the complete
        # parent model (and therefore all parent output rows) while exposing
        # labels for only one active outcome. Select those rows by name rather
        # than assuming ``self.outcome_names`` spans the complete head. The
        # ordinary multi-outcome path is unchanged because its selection is
        # simply every row in the original order.
        unknown = [
            name for name in self.outcome_names if name not in objective.outcome_index
        ]
        if unknown:
            raise ValueError(
                "Validation requested outcomes absent from the competing-risk "
                f"head: {unknown}."
            )
        active_indices = [objective.outcome_index[name] for name in self.outcome_names]
        active_log_hazards = log_hazards[:, active_indices]
        horizons = self.evaluation_horizons_days or [
            float(value) * objective.time_scale_days
            for value in objective.boundaries.detach().cpu().tolist()
        ]
        no_competing = torch.tensor(
            [name in objective.no_competing_outcomes for name in self.outcome_names],
            device=log_hazards.device,
        )
        predictions = piecewise_exponential_cif(
            active_log_hazards.detach(),
            objective.boundaries * objective.time_scale_days,
            horizons,
            time_scale_days=objective.time_scale_days,
            no_competing_outcome_mask=no_competing,
        ).float().cpu()
        for outcome_index, name in enumerate(self.outcome_names):
            survival = outcome_survival.get(name)
            if not survival:
                continue
            times = survival["times"].detach().float().cpu().reshape(-1)
            events = survival["events"].detach().long().cpu().reshape(-1)
            valid = torch.isfinite(times) & (times >= 0) & (events >= 0)
            if not valid.any():
                continue
            store = self._val_cr_predictions.setdefault(
                name, {"times": [], "events": [], "cif": []}
            )
            store["times"].append(times[valid])
            store["events"].append(events[valid])
            store["cif"].append(predictions[valid, outcome_index])

    def _log_competing_risk_validation(self) -> None:
        if self.endpoint_groups and self.trainer.sanity_checking:
            self._val_cr_predictions = {}
            return
        if not self._val_cr_predictions:
            return
        horizons = self.evaluation_horizons_days or [
            float(value) * self.model.competing_risk_loss.time_scale_days
            for value in self.model.competing_risk_loss.boundaries.detach().cpu().tolist()
        ]
        aucs = []
        briers = []
        outcome_aucs = {}
        outcome_briers = {}
        selection_aucs, selection_briers, inventory = {}, {}, []
        for name, store in self._val_cr_predictions.items():
            times = torch.cat(store["times"]).numpy()
            events = torch.cat(store["events"]).numpy()
            cif = torch.cat(store["cif"]).numpy()
            for horizon_index, horizon in enumerate(horizons):
                metrics = compute_competing_risk_metrics_at_horizon(
                    times, events, cif[:, horizon_index], float(horizon)
                )
                suffix = f"{int(horizon)}d"
                auc = float(metrics["cif_auc"])
                brier = float(metrics["cif_brier"])
                if self.endpoint_groups:
                    admitted = (metrics["n_cases"] >= self.selection_min_cases
                                and metrics["n_controls"] >= self.selection_min_controls)
                    inventory.append({"outcome": name, "horizon_days": horizon,
                                      "n_cases": metrics["n_cases"], "n_controls": metrics["n_controls"],
                                      "included": admitted})
                    if admitted:
                        if not np.isfinite(auc) or not np.isfinite(brier):
                            raise RuntimeError("Supported selection cell has nonfinite metrics.")
                        selection_aucs.setdefault(name, []).append(auc)
                        selection_briers.setdefault(name, []).append(brier)
                if np.isfinite(auc):
                    aucs.append(auc)
                    outcome_aucs.setdefault(name, []).append(auc)
                    self.log(f"val/cr_cif_auc/{name}/{suffix}", auc)
                if np.isfinite(brier):
                    briers.append(brier)
                    outcome_briers.setdefault(name, []).append(brier)
                    self.log(f"val/cr_cif_brier/{name}/{suffix}", brier)
        if aucs:
            self.log("val/cr_cif_auc_macro", float(np.mean(aucs)), prog_bar=True)
        if briers:
            self.log("val/cr_cif_brier_macro", float(np.mean(briers)))
        for metric_name, values, higher_is_better in (
            ("auc", outcome_aucs, True),
            ("brier", outcome_briers, False),
        ):
            family_values = {}
            for outcome, outcome_values in values.items():
                family = self.outcome_family.get(outcome)
                if family is not None and outcome_values:
                    family_values.setdefault(family, []).append(
                        float(np.mean(outcome_values))
                    )
            family_means = []
            for family, member_values in family_values.items():
                value = float(np.mean(member_values))
                family_means.append(value)
                family_key = (
                    family.lower().replace(" ", "_").replace("&", "and")
                )
                self.log(f"val/cr_cif_{metric_name}_family/{family_key}", value)
            if family_means:
                self.log(
                    f"val/cr_cif_{metric_name}_family_macro",
                    float(np.mean(family_means)),
                    prog_bar=higher_is_better,
                )
        if self.endpoint_groups:
            from opera.functional.endpoint_groups import endpoint_group_score
            import json
            from pathlib import Path
            # Inventory depends only on tuning labels, never predictions.
            destination = Path(self.trainer.default_root_dir) / "endpoint_selection_inventory.json"
            if destination.exists():
                if json.loads(destination.read_text()) != inventory:
                    raise RuntimeError("Tuning selection inventory changed; use full fixed validation data.")
            else:
                destination.write_text(json.dumps(inventory, indent=2))
            for metric, values in (("auc", selection_aucs), ("brier", selection_briers)):
                score, coverage = endpoint_group_score(values, self.endpoint_groups)
                if not np.isfinite(score):
                    raise RuntimeError("No endpoint groups meet the prespecified tuning support threshold.")
                self.log(f"val/cr_cif_{metric}_endpoint_group_macro", score, prog_bar=metric == "auc")
                self.log(f"val/cr_cif_{metric}_selection_groups", float(coverage))
            self.log("val/cr_cif_selection_cells", float(sum(row["included"] for row in inventory)))
        self._val_cr_predictions = {}

    def on_validation_epoch_end(self):
        """
        Frozen linear probe AUROC on val embeddings, logged per outcome.
        This directly measures representation quality without training overhead —
        the probe is a logistic regression on already-computed frozen embeddings.
        """
        self._log_competing_risk_validation()
        if not hasattr(self, "_val_probe_emb_store") or not self._val_probe_emb_store:
            return

        is_last_epoch = self.current_epoch + 1 >= self.trainer.max_epochs
        should_probe = (
            self.current_epoch + 1
        ) % self.probe_every_n_epochs == 0 or is_last_epoch
        if not should_probe:
            self._val_probe_emb_store = []
            self._val_probe_embs = {n: [] for n in self.outcome_names}
            self._val_probe_labels = {n: [] for n in self.outcome_names}
            return

        try:
            from sklearn.linear_model import LogisticRegression
            from sklearn.metrics import roc_auc_score
            from sklearn.model_selection import train_test_split
            from sklearn.pipeline import make_pipeline
            from sklearn.preprocessing import StandardScaler

            all_embs = torch.cat(self._val_probe_emb_store, dim=0).numpy()

            probe_aurocs = []
            for name in self.outcome_names:
                labels_list = self._val_probe_labels.get(name, [])
                if not labels_list:
                    continue
                labels = torch.cat(labels_list, dim=0).numpy()
                valid = labels >= 0
                if valid.sum() < 40 or len(np.unique(labels[valid])) < 2:
                    continue

                X_all = all_embs[valid]
                y_all = labels[valid]
                try:
                    # Split 80/20 so the probe is scored on held-out data.
                    # stratify ensures both splits have both classes.
                    X_tr, X_ev, y_tr, y_ev = train_test_split(
                        X_all, y_all, test_size=0.2, random_state=0, stratify=y_all
                    )
                    if len(np.unique(y_tr)) < 2 or len(np.unique(y_ev)) < 2:
                        continue
                    clf = make_pipeline(
                        StandardScaler(),
                        LogisticRegression(
                            C=1.0, max_iter=200, solver="lbfgs", warm_start=False
                        ),
                    )
                    clf.fit(X_tr, y_tr)
                    probs = clf.predict_proba(X_ev)[:, 1]
                    auroc = float(roc_auc_score(y_ev, probs))
                    self.log(
                        f"val/diagnostic_ever_event_projection_auroc/{name}",
                        auroc,
                        prog_bar=False,
                    )
                    probe_aurocs.append(auroc)
                except Exception:
                    pass

            if probe_aurocs:
                self.log(
                    "val/diagnostic_ever_event_projection_auroc_mean",
                    float(np.mean(probe_aurocs)),
                    prog_bar=True,
                )

        except ImportError:
            pass  # scikit-learn not available
        finally:
            # Clear accumulators
            self._val_probe_emb_store = []
            self._val_probe_embs = {n: [] for n in self.outcome_names}
            self._val_probe_labels = {n: [] for n in self.outcome_names}

    def configure_optimizers(self):
        encoder_params = []
        head_params = []
        for name, param in self.model.named_parameters():
            if not param.requires_grad:
                continue
            if name.startswith("encoder."):
                encoder_params.append(param)
            else:
                head_params.append(param)

        param_groups = [{"params": head_params, "lr": self.learning_rate}]
        if encoder_params:
            param_groups.append(
                {
                    "params": encoder_params,
                    "lr": self.learning_rate * self.encoder_lr_multiplier,
                }
            )

        optimizer = AdamW(param_groups, eps=self.optimizer_epsilon)

        return optimizer_with_warmup(
            optimizer,
            self.trainer,
            self.scheduler_warmup_epochs,
        )
