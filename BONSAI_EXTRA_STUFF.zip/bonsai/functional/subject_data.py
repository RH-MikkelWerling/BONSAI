import copy
import logging
from pathlib import Path
from typing import List, Dict, Iterable
import torch
import polars as pl


def clone_subject(subject: Dict) -> Dict:
    """Clone a subject record without sharing mutable tensor storage."""
    return {
        key: value.clone() if isinstance(value, torch.Tensor) else copy.deepcopy(value)
        for key, value in subject.items()
    }


def prepare_subject_data(split_path: Path) -> List[Dict[str, torch.Tensor]]:
    """Load tokenized data and prepare it in the format needed for the models (subject_data)."""
    all_tokenized = []
    for shard in split_path.glob("*.parquet"):
        tokenized_data = pl.read_parquet(shard)
        # Convert to training format
        for subject_id, group in tokenized_data.group_by(
            "subject_id", maintain_order=True
        ):
            subject = {"subject_id": subject_id[0]}
            for column in group.columns:
                if column == "subject_id":
                    continue
                subject[column] = group[column].to_torch()
            all_tokenized.append(subject)

    return all_tokenized


def filter_subject_data(subject_data: List[dict], cohort: Iterable[int]) -> List[dict]:
    """Filter subject_data to only include subjects in the cohort."""
    pre = len(subject_data)
    cohort_set = set(cohort)  # Convert to set for faster lookup
    filtered_subjects = [s for s in subject_data if s["subject_id"] in cohort_set]
    post = len(filtered_subjects)
    logging.info(f"filter_subject_data: {pre} -> {post} subjects")
    return filtered_subjects
