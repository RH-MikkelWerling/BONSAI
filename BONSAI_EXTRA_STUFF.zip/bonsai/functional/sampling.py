from typing import List, Optional
from collections import Counter
from torch.utils.data import WeightedRandomSampler
import numpy as np
from hydra.utils import instantiate


def get_sampler(weight_fn, labels) -> Optional[WeightedRandomSampler]:
    if weight_fn is None:
        return None
    label_counts = Counter(labels)
    label_weight = instantiate(
        weight_fn,
        labels=labels,
        label_counts=label_counts,
    )
    return WeightedRandomSampler(
        weights=label_weight, num_samples=len(labels), replacement=True
    )


def inverse_sqrt(labels: List[int], label_counts: dict) -> List[float]:
    """Calculate the inverse square root of class frequencies."""
    weights = {k: 1 / np.sqrt(v) for k, v in label_counts.items()}
    # Map weights back to samples
    return [weights[label] for label in labels]


def effective_n_samples(labels: List[int], label_counts: dict) -> List[float]:
    """Calculate weights using the effective number of samples method."""
    # Calculate beta as per the paper
    beta = (len(labels) - 1) / len(labels)

    # Calculate effective number for each class
    effective_nums = {
        label: (1 - (beta**count)) / (1 - beta) for label, count in label_counts.items()
    }

    # Calculate class probabilities
    total_effective = sum(effective_nums.values())
    class_probs = {
        label: eff_num / total_effective for label, eff_num in effective_nums.items()
    }

    # Calculate weights for each sample
    return [class_probs[outcome] / label_counts[outcome] for outcome in labels]
