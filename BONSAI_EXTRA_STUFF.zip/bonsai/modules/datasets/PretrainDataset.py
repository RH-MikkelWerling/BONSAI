from datetime import datetime
from typing import Dict, List, Optional, Tuple

import torch
from torch.utils.data import Dataset

from bonsai.functional.censoring import censor_subject
from bonsai.functional.features import compute_abspos
from bonsai.functional.normalization import normalize_segments
from bonsai.functional.subject_data import clone_subject
from bonsai.functional.truncation import (
    infer_background_length,
    sequence_tensor_fields,
    subject_window_count,
    truncate_subject,
)


class PretrainDataset(Dataset):
    def __init__(
        self,
        subjects: List[Dict],
        max_len: int,
        background_length: Optional[int],
        cutoff_date: Optional[dict] = None,
        truncation_strategy: str = "tail",
        tail_window_probability: float = 0.5,
        generator: Optional[torch.Generator] = None,
        numeric_value_control: str = "observed",
        abspos_subject_jitter_years: float = 0.0,
    ):
        self.subjects = subjects
        self.max_len = max_len
        self.background_length = background_length
        self.truncation_strategy = truncation_strategy
        self.tail_window_probability = tail_window_probability
        self.generator = generator
        if numeric_value_control not in {"observed", "masked"}:
            raise ValueError("numeric_value_control must be 'observed' or 'masked'.")
        self.numeric_value_control = numeric_value_control
        if abspos_subject_jitter_years < 0:
            raise ValueError("abspos_subject_jitter_years must be non-negative.")
        self.abspos_subject_jitter_years = float(abspos_subject_jitter_years)
        self.cutoff_date = (
            compute_abspos(datetime(**cutoff_date)) if cutoff_date is not None else None
        )
        self.sample_index = [(index, None) for index in range(len(subjects))]
        if self.truncation_strategy == "all_windows":
            self.sample_index = []
            for subject_index, raw_subject in enumerate(self.subjects):
                background_length = (
                    infer_background_length(raw_subject)
                    if self.background_length is None
                    else int(self.background_length)
                )
                subject = (
                    censor_subject(raw_subject, self.cutoff_date, inclusive=False)
                    if self.cutoff_date is not None
                    else raw_subject
                )
                n_windows = subject_window_count(
                    subject, self.max_len, background_length
                )
                self.sample_index.extend(
                    (subject_index, window_index)
                    for window_index in range(n_windows)
                )

    def _prepare_subject(self, index: int) -> tuple[dict, dict]:
        subject_index, window_index = self.sample_index[index]
        subject = clone_subject(self.subjects[subject_index])
        background_length = (
            infer_background_length(subject)
            if self.background_length is None
            else int(self.background_length)
        )
        if self.cutoff_date is not None:
            subject = censor_subject(subject, self.cutoff_date, inclusive=False)
        truncated_subject, truncation_metadata = truncate_subject(
            subject,
            self.max_len,
            background_length,
            strategy=self.truncation_strategy,
            tail_window_probability=self.tail_window_probability,
            generator=self.generator,
            window_index=window_index,
            return_metadata=True,
        )
        truncated_subject["attention_mask"] = torch.ones(
            len(truncated_subject["code"]), dtype=torch.bool
        )
        truncated_subject["segment"] = normalize_segments(truncated_subject["segment"])
        if self.abspos_subject_jitter_years:
            jitter = torch.randn((), generator=self.generator)
            jitter = jitter * self.abspos_subject_jitter_years * 8766.0
            valid_time = truncated_subject["code"] != 0
            truncated_subject["abspos"] = truncated_subject["abspos"].clone()
            truncated_subject["abspos"][valid_time] += jitter.to(
                truncated_subject["abspos"].dtype
            )
        if (
            self.numeric_value_control == "masked"
            and "numeric_value" in truncated_subject
        ):
            truncated_subject["numeric_value"] = torch.full_like(
                truncated_subject["numeric_value"], float("nan")
            )
        return truncated_subject, truncation_metadata

    def __getitem__(self, index: int) -> dict:
        truncated_subject, _ = self._prepare_subject(index)
        return truncated_subject

    def __len__(self):
        return len(self.sample_index)


class MLMPretrainDataset(PretrainDataset):
    def __init__(
        self,
        subjects: List[Dict],
        max_len: int,
        background_length: int,
        vocabulary: Dict[str, int],
        masking_select_ratio: float,
        masking_mask_ratio: float = 0.8,
        masking_random_ratio: float = 0.1,
        masking_ignore_special_tokens: bool = True,
        cutoff_date: Optional[dict] = None,
        truncation_strategy: str = "tail",
        tail_window_probability: float = 0.5,
        generator: Optional[torch.Generator] = None,
        numeric_value_control: str = "observed",
        abspos_subject_jitter_years: float = 0.0,
    ):
        super().__init__(
            subjects,
            max_len,
            background_length,
            cutoff_date=cutoff_date,
            truncation_strategy=truncation_strategy,
            tail_window_probability=tail_window_probability,
            generator=generator,
            numeric_value_control=numeric_value_control,
            abspos_subject_jitter_years=abspos_subject_jitter_years,
        )
        self.vocabulary = vocabulary

        self.masking_select_ratio = masking_select_ratio
        self.masking_mask_ratio = masking_mask_ratio
        self.masking_random_ratio = masking_random_ratio
        self.masking_n_special_tokens = (
            len([token for token in vocabulary if token.startswith("[")])
            if masking_ignore_special_tokens
            else 0
        )

    def __getitem__(self, index: int) -> dict:
        subject, _ = self._prepare_subject(index)
        masked_codes, target, selected_indices = self.mask_patient_codes(
            subject["code"]
        )
        self._prepare_value_targets(subject, selected_indices)
        self._prepare_continuous_value_targets(subject, selected_indices)
        subject["code"] = masked_codes
        subject["target"] = target
        return subject

    def mask_patient_codes(
        self, codes: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        target = codes.clone()
        probability_vector = torch.full(target.shape, self.masking_select_ratio)

        # Ignore special tokens
        special_token_mask = codes < self.masking_n_special_tokens
        probability_vector.masked_fill_(special_token_mask, value=0.0)

        # Get MLM mask
        selected_indices = torch.bernoulli(probability_vector).bool()
        target[~selected_indices] = -100

        # Replace with [MASK]
        indices_mask = (
            torch.bernoulli(torch.full(target.shape, self.masking_mask_ratio)).bool()
            & selected_indices
        )
        codes[indices_mask] = self.vocabulary["[MASK]"]

        # Replace with random word and Account for already masked tokens
        random_ratio = self.masking_random_ratio / (1 - self.masking_mask_ratio)
        indicies_random = (
            torch.bernoulli(torch.full(target.shape, random_ratio)).bool()
            & selected_indices
            & ~indices_mask
        )
        random_words = torch.randint(
            self.masking_n_special_tokens,
            len(self.vocabulary),
            target.shape,
            dtype=codes.dtype,
        )
        codes[indicies_random] = random_words[indicies_random]
        return codes, target, selected_indices

    def _prepare_value_targets(
        self,
        subject: dict,
        selected_indices: torch.Tensor,
    ) -> None:
        if not {
            "value_bin",
            "value_normalized",
            "value_present",
        }.issubset(subject):
            return
        value_mask = selected_indices & subject["value_present"].bool()
        subject["target_value_mask"] = value_mask
        subject["target_value_bin"] = subject["value_bin"].clone()
        subject["target_value_bin"][~value_mask] = -100
        subject["target_value_normalized"] = subject["value_normalized"].clone()
        subject["target_value_normalized"][~value_mask] = 0.0
        subject["value_bin"] = subject["value_bin"].clone()
        subject["value_normalized"] = subject["value_normalized"].clone()
        subject["value_present"] = subject["value_present"].clone()
        subject["value_bin"][value_mask] = 0
        subject["value_normalized"][value_mask] = 0.0
        subject["value_present"][value_mask] = False

    @staticmethod
    def _prepare_continuous_value_targets(
        subject: dict,
        selected_indices: torch.Tensor,
    ) -> None:
        if "numeric_value" not in subject:
            return
        numeric_target = subject["numeric_value"].clone()
        numeric_target[~selected_indices] = float("nan")
        subject["numeric_target"] = numeric_target
        subject["numeric_value"] = subject["numeric_value"].clone()
        subject["numeric_value"][selected_indices] = float("nan")


class ARPretrainDataset(PretrainDataset):
    def __init__(
        self,
        subjects: List[Dict],
        max_len: int,
        background_length: int,
        cutoff_date: Optional[dict] = None,
        truncation_strategy: str = "tail",
        tail_window_probability: float = 0.5,
        generator: Optional[torch.Generator] = None,
        vocabulary: Optional[Dict[str, int]] = None,
        value_embedding_mode: str = "legacy",
        numeric_value_control: str = "observed",
        abspos_subject_jitter_years: float = 0.0,
        ignore_target_tokens: Optional[List[str]] = None,
        input_only_target_prefixes: Optional[List[str]] = None,
        ignore_same_time_targets: bool = False,
        event_normalized_code_loss: bool = False,
    ):
        super().__init__(
            subjects,
            max_len + 1,
            background_length,
            cutoff_date=cutoff_date,
            truncation_strategy=truncation_strategy,
            tail_window_probability=tail_window_probability,
            generator=generator,
            numeric_value_control=numeric_value_control,
            abspos_subject_jitter_years=abspos_subject_jitter_years,
        )  # +1 because we shift by one token in __getitem__
        self.val_token_id = None if vocabulary is None else vocabulary.get("[VAL]")
        self.value_embedding_mode = value_embedding_mode
        ignore_target_tokens = ignore_target_tokens or []
        if ignore_target_tokens and vocabulary is None:
            raise ValueError("ignore_target_tokens requires a vocabulary.")
        missing = [token for token in ignore_target_tokens if token not in vocabulary]
        if missing:
            raise ValueError(
                f"Ignored target tokens are absent from vocabulary: {missing}"
            )
        self.ignore_target_token_ids = {
            int(vocabulary[token]) for token in ignore_target_tokens
        }
        self.input_only_target_prefixes = tuple(input_only_target_prefixes or [])
        if self.input_only_target_prefixes and vocabulary is None:
            raise ValueError("input_only_target_prefixes requires a vocabulary.")
        self.input_only_target_ids = {
            int(token_id)
            for token, token_id in (vocabulary or {}).items()
            if any(
                str(token).startswith(prefix)
                for prefix in self.input_only_target_prefixes
            )
        }
        self.ignore_same_time_targets = bool(ignore_same_time_targets)
        self.event_normalized_code_loss = bool(event_normalized_code_loss)

    def __getitem__(self, index: int) -> dict:
        subject, truncation_metadata = self._prepare_subject(index)
        subject["target"] = subject["code"][1:]
        subject["target"] = subject["target"].masked_fill(subject["target"] == 0, -100)
        for token_id in self.ignore_target_token_ids:
            subject["target"].masked_fill_(subject["target"] == token_id, -100)
        for token_id in self.input_only_target_ids:
            subject["target"].masked_fill_(subject["target"] == token_id, -100)
        if self.ignore_same_time_targets:
            # Canonical MEDS order is retained as input context, but predicting
            # the arbitrary ordering of codes sharing an exact timestamp is
            # not treated as a learnable clinical objective.
            same_time = subject["abspos"][:-1] == subject["abspos"][1:]
            subject["target"].masked_fill_(same_time, -100)
        has_values = {
            "value_bin",
            "value_normalized",
            "value_present",
        }.issubset(subject)
        if has_values:
            value_mask = subject["value_present"][1:].bool()
            subject["target_value_mask"] = value_mask
            subject["target_value_bin"] = subject["value_bin"][1:].clone()
            subject["target_value_bin"][~value_mask] = -100
            subject["target_value_normalized"] = subject["value_normalized"][1:].clone()
            subject["target_value_normalized"][~value_mask] = 0.0
            if self.value_embedding_mode == "combined_binning":
                # In causal training, the state at the owning lab event
                # predicts the following [VAL] scalar. Avoid an additional,
                # nearly trivial CE target for the shared marker token.
                if self.val_token_id is None:
                    raise ValueError(
                        "combined_binning requires [VAL] in the vocabulary."
                    )
                value_mask = value_mask & (subject["code"][1:] == self.val_token_id)
                subject["target_value_mask"] = value_mask
                subject["target_value_bin"][~value_mask] = -100
                subject["target"][subject["code"][1:] == self.val_token_id] = -100
        if "numeric_value" in subject:
            subject["numeric_target"] = subject["numeric_value"][1:].clone()
        if truncation_metadata["clinical_window_started_mid_history"]:
            boundary_target = int(truncation_metadata["background_length"]) - 1
            if 0 <= boundary_target < len(subject["target"]):
                subject["target"][boundary_target] = -100
                if has_values:
                    subject["target_value_mask"][boundary_target] = False
                    subject["target_value_bin"][boundary_target] = -100
                    subject["target_value_normalized"][boundary_target] = 0.0
                if "numeric_target" in subject:
                    subject["numeric_target"][boundary_target] = float("nan")
        if self.event_normalized_code_loss:
            # A timestamped event contributes unit total code-loss mass,
            # irrespective of how many eligible serialized targets it owns.
            # Targets excluded above remain visible inputs but receive no mass.
            target_abspos = subject["abspos"][1:]
            eligible = subject["target"] != -100
            code_loss_weight = torch.zeros_like(target_abspos, dtype=torch.float)
            if eligible.any():
                _, inverse, counts = torch.unique(
                    target_abspos[eligible], return_inverse=True, return_counts=True
                )
                code_loss_weight[eligible] = counts[inverse].reciprocal().float()
            subject["code_loss_weight"] = code_loss_weight
        for key in sequence_tensor_fields(subject):
            subject[key] = subject[key][:-1]
        return subject
