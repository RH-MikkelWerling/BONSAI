from typing import Literal, Dict, Optional
import polars as pl
import lightning as L
import torch
from torch.utils.data import DataLoader, WeightedRandomSampler
from bonsai.functional.collate import dynamic_padding
from bonsai.modules.datasets.FinetuneDataset import FinetuneDataset
from bonsai.functional.subject_data import filter_subject_data


class FinetuneDataModule(L.LightningDataModule):
    def __init__(
        self,
        path_train_data: str,
        path_val_data: str,
        path_predict_data: str,
        path_population: str,
        batch_size: int,
        num_workers: int,
        predict_token_id: int,
        max_len: int,
        train_outcomes: Dict[int, dict],
        val_outcomes: Dict[int, dict],
        predict_outcomes: Dict[int, dict],
        train_sampler: Optional[WeightedRandomSampler] = None,
        numeric_value_control: str = "observed",
    ):
        super().__init__()
        self.path_train_data = path_train_data
        self.path_val_data = path_val_data
        self.path_predict_data = path_predict_data
        self.population = pl.read_csv(path_population)

        self.batch_size = batch_size
        self.num_workers = num_workers
        self.predict_token_id = predict_token_id
        self.max_len = max_len

        self.train_outcomes = train_outcomes
        self.val_outcomes = val_outcomes
        self.predict_outcomes = predict_outcomes
        self.train_sampler = train_sampler
        self.numeric_value_control = numeric_value_control

    def setup(self, stage: Literal["fit", "test", "predict"]):
        if stage == "fit":
            self.setup_fit()
        elif stage == "test":
            raise NotImplementedError("Test stage not supported for PretrainModule.")
        elif stage == "predict":
            self.setup_predict()

    def setup_fit(self):
        train_data = torch.load(self.path_train_data)
        val_data = torch.load(self.path_val_data)

        train_data = [
            sub for sub in train_data if sub["subject_id"] in self.train_outcomes
        ]
        val_data = [sub for sub in val_data if sub["subject_id"] in self.val_outcomes]

        population_subject_ids = self.population["subject_id"].to_list()
        train_data = filter_subject_data(train_data, population_subject_ids)
        val_data = filter_subject_data(val_data, population_subject_ids)
        if not train_data:
            raise ValueError(
                "No training subjects remain after outcome/population filtering."
            )
        if not val_data:
            raise ValueError(
                "No validation subjects remain after outcome/population filtering."
            )

        self.train_dataset = FinetuneDataset(
            train_data,
            outcomes=self.train_outcomes,
            predict_token_id=self.predict_token_id,
            background_length=None,
            max_len=self.max_len,
            numeric_value_control=self.numeric_value_control,
        )
        self.val_dataset = FinetuneDataset(
            val_data,
            outcomes=self.val_outcomes,
            predict_token_id=self.predict_token_id,
            background_length=None,
            max_len=self.max_len,
            numeric_value_control=self.numeric_value_control,
        )

    def setup_predict(self):
        if self.path_predict_data is None:
            raise ValueError("path_predict_data must be set before running predict.")
        predict_data = torch.load(self.path_predict_data)
        predict_data = [
            sub for sub in predict_data if sub["subject_id"] in self.predict_outcomes
        ]
        population_subject_ids = self.population["subject_id"].to_list()
        predict_data = filter_subject_data(predict_data, population_subject_ids)
        if not predict_data:
            raise ValueError(
                "No prediction subjects remain after outcome/population filtering."
            )
        self.predict_dataset = FinetuneDataset(
            predict_data,
            outcomes=self.predict_outcomes,
            predict_token_id=self.predict_token_id,
            background_length=None,
            max_len=self.max_len,
            numeric_value_control=self.numeric_value_control,
        )

    def train_dataloader(self):
        return DataLoader(
            self.train_dataset,
            num_workers=self.num_workers,
            batch_size=self.batch_size,
            pin_memory=True,
            persistent_workers=self.num_workers > 0,
            drop_last=False,
            collate_fn=dynamic_padding,
            sampler=self.train_sampler,
            shuffle=self.train_sampler is None,
        )

    def val_dataloader(self):
        return DataLoader(
            self.val_dataset,
            num_workers=self.num_workers,
            batch_size=self.batch_size,
            pin_memory=True,
            persistent_workers=self.num_workers > 0,
            drop_last=False,
            shuffle=False,
            collate_fn=dynamic_padding,
        )

    def predict_dataloader(self):
        return DataLoader(
            self.predict_dataset,
            num_workers=self.num_workers,
            batch_size=self.batch_size,
            pin_memory=True,
            persistent_workers=self.num_workers > 0,
            drop_last=False,
            shuffle=False,
            collate_fn=dynamic_padding,
        )
