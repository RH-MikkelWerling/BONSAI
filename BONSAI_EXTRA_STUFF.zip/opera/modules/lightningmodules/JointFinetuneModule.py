"""
Lightning module for OPERA joint multi-task finetuning.

Trains a single model on all cohorts and all outcomes simultaneously.
Logs per-outcome AUROC on validation so you can monitor which outcomes
are learning and which are struggling.
"""

import lightning as L
import torch
from torch import nn
from torch.optim import AdamW
from torchmetrics import AUROC, AveragePrecision
from typing import Dict, List
from bonsai.functional.checkpointing import (
    MODEL_INIT_CONFIG_KEY,
    attach_checkpoint_metadata,
    attach_model_config,
)
from bonsai.functional.scheduling import optimizer_with_warmup
from opera.compat.bonsai import encoder_hparams


class JointFinetuneModule(L.LightningModule):
    """
    Parameters
    ----------
    model         : JointFinetuneModel
    outcome_names : must match model.outcome_names
    learning_rate : head LR
    encoder_lr_multiplier : encoder LR = learning_rate * this
                            (lower than heads — encoder is already pretrained)
    """

    def __init__(
        self,
        model: nn.Module,
        outcome_names: List[str],
        learning_rate: float = 5e-4,
        encoder_lr_multiplier: float = 0.1,
        optimizer_epsilon: float = 1e-6,
        scheduler_warmup_epochs: int = 1,
        checkpoint_metadata: dict = None,
    ):
        super().__init__()
        self.save_hyperparameters(ignore=["model"])
        attach_model_config(self, model)
        self.hparams[MODEL_INIT_CONFIG_KEY] = {
            "hidden_size": encoder_hparams(model.encoder)["hidden_size"],
            "pooling": model.pooling,
            "freeze_encoder": model.freeze_encoder,
            "dropout": model.dropout.p,
            "cross_outcome_config": dict(getattr(model, "cross_outcome_config", {})),
        }
        attach_checkpoint_metadata(self, checkpoint_metadata)
        self.model = model
        self.outcome_names = outcome_names

        # Per-outcome validation metrics
        self.val_auroc = nn.ModuleDict(
            {name: AUROC(task="binary") for name in outcome_names}
        )
        self.val_auprc = nn.ModuleDict(
            {name: AveragePrecision(task="binary") for name in outcome_names}
        )

    def _build_outcome_labels(self, batch: dict) -> Dict[str, torch.Tensor]:
        return {
            name: batch[f"outcome_{name}"]
            for name in self.outcome_names
            if f"outcome_{name}" in batch
        }

    def training_step(self, batch, batch_idx):
        outcome_labels = self._build_outcome_labels(batch)
        log_dict = self.model(batch, outcome_labels)
        loss = log_dict["loss"]

        self.log("train/loss", loss, prog_bar=True)
        for k, v in log_dict.items():
            if k.startswith(
                (
                    "loss/",
                    "sigma/",
                    "null_reference_loss/",
                    "normalized_loss/",
                    "effective_raw_loss_weight/",
                )
            ):
                self.log(f"train/{k}", v)
        return loss

    def validation_step(self, batch, batch_idx):
        outcome_labels = self._build_outcome_labels(batch)
        log_dict = self.model(batch, outcome_labels)
        loss = log_dict["loss"]
        self.log("val/loss", loss, prog_bar=True)

        # Update per-outcome metrics
        for name in self.outcome_names:
            labels_k = outcome_labels.get(name)
            if labels_k is None:
                continue
            valid = labels_k >= 0
            if valid.sum() == 0:
                continue
            logits_k = log_dict.get(f"logits/{name}")
            if logits_k is None:
                continue
            labels_v = labels_k[valid]

            probs_k = torch.sigmoid(logits_k)
            self.val_auroc[name].update(probs_k, labels_v)
            self.val_auprc[name].update(probs_k, labels_v)

        return loss

    def on_validation_epoch_end(self):
        aurocs = []
        for name in self.outcome_names:
            try:
                auroc = self.val_auroc[name].compute()
                auprc = self.val_auprc[name].compute()
                if not torch.isfinite(auroc):
                    self.val_auroc[name].reset()
                    self.val_auprc[name].reset()
                    continue
                self.log(f"val/auroc_{name}", auroc)
                if torch.isfinite(auprc):
                    self.log(f"val/auprc_{name}", auprc)
                aurocs.append(auroc)
                self.val_auroc[name].reset()
                self.val_auprc[name].reset()
            except (RuntimeError, ValueError):
                self.val_auroc[name].reset()
                self.val_auprc[name].reset()
                continue

        # Macro-average AUROC normalised over ALL configured outcomes.
        # Outcomes that produced no finite AUROC this epoch (single-class val
        # batches, rare events) contribute 0.5 (random baseline) rather than
        # being excluded from the denominator.  This keeps the metric
        # epoch-consistent: a model improving purely because more outcomes
        # happened to produce finite AUROCs in epoch N vs. N-1 will no longer
        # appear to improve.  It also prevents EarlyStopping from firing
        # prematurely during cold-start epochs when no rare outcome has both
        # classes in the tuning split yet.
        n_configured = len(self.outcome_names)
        if not aurocs:
            import warnings

            warnings.warn(
                "No validation outcome produced a finite AUROC this epoch. "
                "Check that at least one outcome has both classes after "
                "eligibility and minimum-follow-up filtering.",
                stacklevel=2,
            )
            self.log("val/auroc_macro", 0.5, prog_bar=True)
            return
        macro = (
            torch.stack(aurocs).sum() + 0.5 * (n_configured - len(aurocs))
        ) / n_configured
        self.log("val/auroc_macro", macro, prog_bar=True)

    def configure_optimizers(self):
        lr = self.hparams.learning_rate
        enc_mult = self.hparams.encoder_lr_multiplier

        encoder_params, head_params = [], []
        for name, param in self.model.named_parameters():
            if not param.requires_grad:
                continue
            if name.startswith("encoder."):
                encoder_params.append(param)
            else:
                head_params.append(param)

        param_groups = [{"params": head_params, "lr": lr}]
        if encoder_params:
            param_groups.append({"params": encoder_params, "lr": lr * enc_mult})

        optimizer = AdamW(param_groups, eps=self.hparams.optimizer_epsilon)
        return optimizer_with_warmup(
            optimizer,
            self.trainer,
            self.hparams.scheduler_warmup_epochs,
        )
