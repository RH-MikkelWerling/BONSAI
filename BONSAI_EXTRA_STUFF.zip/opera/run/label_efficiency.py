"""
Label efficiency experiments.

Runs finetune + evaluate at multiple training set fractions to produce
learning curves. Supports either the legacy single cohort/outcome CLI or a
comma-separated list of cohort:outcome tasks.
"""

import argparse
import json
import subprocess
import sys
import warnings
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from omegaconf import OmegaConf
from opera.compat.bonsai import binarize_outcomes
from opera.evaluation.tasks import (
    competing_outcome_file_path,
    normalize_outcome_config,
    outcome_file_path,
    parse_task_ref,
)
from opera.evaluation.cohort_flow import eligibility_file_path
from opera.evaluation.cohorts import population_subject_ids
from opera.functional.outcomes import (
    attach_prediction_censor_abspos,
    filter_outcome_eligibility,
    filter_registry_eligible_outcomes,
    resolve_registry_start_date,
)


def _allocate_stratified_counts(
    train_df: pd.DataFrame, n_sample: int
) -> Dict[int, int]:
    counts = train_df["label"].value_counts().sort_index()
    labels = list(counts.index)
    if n_sample < len(labels):
        return {}

    total = float(counts.sum())
    raw = {label: n_sample * (count / total) for label, count in counts.items()}
    allocated = {
        label: min(int(counts[label]), max(1, int(np.floor(raw[label]))))
        for label in labels
    }

    while sum(allocated.values()) < n_sample:
        candidates = [
            label for label in labels if allocated[label] < int(counts[label])
        ]
        if not candidates:
            break
        label = max(candidates, key=lambda item: raw[item] - allocated[item])
        allocated[label] += 1

    while sum(allocated.values()) > n_sample:
        candidates = [label for label in labels if allocated[label] > 1]
        if not candidates:
            break
        label = min(candidates, key=lambda item: raw[item] - np.floor(raw[item]))
        allocated[label] -= 1

    return {int(label): int(n) for label, n in allocated.items() if n > 0}


def subsample_outcome_parquet(
    outcome_path: str,
    fraction: float,
    seed: int,
    output_path: str,
    split: str = "train",
    n_hours_start_include: int = 1,
    n_hours_end_include=None,
    registry_start_date: Optional[str] = None,
    cohort: Optional[str] = None,
    outcome_name: Optional[str] = None,
    eligibility_path: Optional[str] = None,
    competing_outcome_path: Optional[str] = None,
    target_subject_ids: Optional[set] = None,
) -> str:
    """
    Subsample the training split of an outcome parquet.

    Validation and test splits are preserved unchanged. If a binary label column
    is already present, sampling is stratified to preserve event rate.
    """
    df = pd.read_parquet(outcome_path)
    df = filter_outcome_eligibility(
        df,
        eligibility_path,
        cohort=cohort,
        outcome_name=outcome_name,
        eligibility_scope="final",
    )
    if "index_date" in df.columns:
        df = attach_prediction_censor_abspos(df)
    elif registry_start_date not in (None, "", "null"):
        raise ValueError(
            "registry_start_date requires an index_date column in the outcome file."
        )
    df = filter_registry_eligible_outcomes(
        df,
        registry_start_date,
        cohort=cohort,
        outcome_name=outcome_name,
    )
    train_mask = df["split"] == split
    if target_subject_ids is not None:
        # Only reduce labels belonging to the target disease. Retain every
        # non-target training row so the same artifact supports both local
        # training (membership-filtered downstream) and pooled scaffolding.
        train_mask &= df["subject_id"].isin(set(target_subject_ids))
    train_df = df[train_mask]
    other_df = df[~train_mask]

    sampling_df = train_df
    sampling_label_col = "label"
    if {
        "subject_id",
        "outcome_date",
        "index_date",
        "censor_date",
    }.issubset(sampling_df.columns):
        competing_df = (
            pd.read_parquet(competing_outcome_path) if competing_outcome_path else None
        )
        derived = binarize_outcomes(
            sampling_df,
            n_hours_start_include=n_hours_start_include,
            n_hours_end_include=n_hours_end_include,
            require_min_followup=True,
            split_name=split,
            competing_event_df=competing_df,
        )
        sampling_df = train_df[train_df["subject_id"].isin(derived)].copy()
        sampling_df["_sampling_label"] = sampling_df["subject_id"].map(
            {sid: record["label"] for sid, record in derived.items()}
        )
        sampling_label_col = "_sampling_label"

    n_sample = min(
        len(sampling_df),
        max(1, int(len(sampling_df) * fraction)),
    )

    if (
        sampling_label_col in sampling_df.columns
        and sampling_df[sampling_label_col].nunique() > 1
    ):
        allocation = _allocate_stratified_counts(
            sampling_df.rename(columns={sampling_label_col: "label"}),
            n_sample,
        )
        if allocation:
            sampled_parts = []
            for label, n_label in allocation.items():
                group = sampling_df[sampling_df[sampling_label_col] == label]
                sampled_parts.append(group.sample(n_label, random_state=seed))
            sampled = pd.concat(sampled_parts)[train_df.columns]
        else:
            warnings.warn(
                "Exact stratified subsampling is impossible for this tiny "
                f"fraction: requested n_sample={n_sample} across "
                f"{sampling_df[sampling_label_col].nunique()} classes. Falling back to "
                "unstratified sampling while preserving the requested total.",
                RuntimeWarning,
                stacklevel=2,
            )
            sampled = sampling_df.sample(n_sample, random_state=seed)[train_df.columns]
    else:
        sampled = sampling_df.sample(n_sample, random_state=seed)[train_df.columns]

    result = pd.concat([sampled, other_df])
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    result.to_parquet(output_path)
    return output_path


def outcome_split_size_metadata(
    outcome_path: str,
    registry_start_date: Optional[str] = None,
    cohort: Optional[str] = None,
    outcome_name: Optional[str] = None,
    eligibility_path: Optional[str] = None,
    competing_outcome_path: Optional[str] = None,
    n_hours_start_include: int = 1,
    n_hours_end_include=None,
    allowed_subject_ids: Optional[set] = None,
) -> Dict[str, float]:
    df = pd.read_parquet(outcome_path)
    df = filter_outcome_eligibility(
        df,
        eligibility_path,
        cohort=cohort,
        outcome_name=outcome_name,
        eligibility_scope="final",
    )
    if "index_date" in df.columns:
        df = attach_prediction_censor_abspos(df)
    elif registry_start_date not in (None, "", "null"):
        raise ValueError(
            "registry_start_date requires an index_date column in the outcome file."
        )
    df = filter_registry_eligible_outcomes(
        df,
        registry_start_date,
        cohort=cohort,
        outcome_name=outcome_name,
    )
    if allowed_subject_ids is not None:
        df = df[df["subject_id"].isin(set(allowed_subject_ids))].copy()
    out: Dict[str, float] = {}
    competing_df = (
        pd.read_parquet(competing_outcome_path) if competing_outcome_path else None
    )
    for split_name, result_key in (
        ("train", "train"),
        ("tuning", "val"),
        ("held_out", "test"),
    ):
        split_df = df[df["split"] == split_name]
        if {"subject_id", "index_date", "censor_date"}.issubset(split_df.columns):
            records = binarize_outcomes(
                split_df,
                n_hours_start_include=n_hours_start_include,
                n_hours_end_include=n_hours_end_include,
                require_min_followup=True,
                split_name=split_name,
                competing_event_df=competing_df,
            )
            n_subjects = len(records)
            n_events = int(sum(record["label"] == 1 for record in records.values()))
            out[f"n_events_{result_key}"] = n_events
            out[f"prevalence_{result_key}"] = (
                float(n_events / n_subjects) if n_subjects else float("nan")
            )
        elif "subject_id" in split_df.columns:
            n_subjects = int(split_df["subject_id"].nunique())
        else:
            n_subjects = int(len(split_df))
        out[f"n_{result_key}"] = n_subjects
        if "label" in split_df.columns and f"n_events_{result_key}" not in out:
            n_events = int(split_df["label"].sum())
            out[f"n_events_{result_key}"] = n_events
            out[f"prevalence_{result_key}"] = (
                float(n_events / n_subjects) if n_subjects else float("nan")
            )
    return out


def run_finetune_and_evaluate(
    encoder_ckpt: str,
    encoder_source: str,
    cohort: str,
    outcome_name: str,
    cohort_data_dir: str,
    outcome_parquet: str,
    output_dir: Path,
    training_fraction: float,
    rarity_metadata: Optional[Dict[str, float]] = None,
    baseline_model: Optional[str] = None,
    base_config: str = "opera/configs/finetune.yaml",
    registry_start_date: Optional[str] = None,
    eligibility_path: Optional[str] = None,
    competing_outcome_path: Optional[str] = None,
    population_path: Optional[str] = None,
    cohort_fine_col: Optional[str] = None,
    cohort_fine_value: Optional[str] = None,
    pooled_training: bool = False,
    seed: int = 42,
    variant_overrides: Optional[List[str]] = None,
    training_mode: Optional[str] = None,
) -> Dict:
    """Run finetune then evaluate, returning metrics.json contents."""
    ft_overrides = [
        f"encoder_ckpt={encoder_ckpt}",
        f"encoder_source={encoder_source}",
        f"dataset={cohort}",
        f"outcome={outcome_name}",
        f"paths.dir={cohort_data_dir}",
        f"paths.outcome={outcome_parquet}",
        f"labels.registry_start_date={'null' if registry_start_date is None else registry_start_date}",
        f"hydra.run.dir={output_dir}",
        f"training.seed={seed}",
    ]
    if training_mode:
        ft_overrides.append(f"training_mode={training_mode}")
    ft_overrides.extend(list(variant_overrides or []))
    if eligibility_path:
        ft_overrides.append(f"paths.eligibility={eligibility_path}")
    if competing_outcome_path:
        ft_overrides.append(f"paths.competing_outcome={competing_outcome_path}")
    if population_path:
        ft_overrides.append(f"paths.population={population_path}")
    if cohort_fine_col and cohort_fine_value and not pooled_training:
        ft_overrides.extend(
            [
                f"cohort_fine_col={cohort_fine_col}",
                f"cohort_fine_value={cohort_fine_value}",
            ]
        )
    runner_module = (
        "opera.run.survival_finetune"
        if "survival" in Path(base_config).stem
        else "opera.run.finetune"
    )
    ft_cmd = [
        sys.executable,
        "-m",
        runner_module,
        f"--config-name={Path(base_config).stem}",
    ] + ft_overrides
    result = subprocess.run(ft_cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"    Finetune failed:\n{result.stderr[-500:]}")
        return {}

    ev_overrides = [
        f"run_dir={output_dir}",
        f"dataset={cohort}",
        f"outcome={outcome_name}",
        f"paths.dir={cohort_data_dir}",
        f"paths.outcome={outcome_parquet}",
        f"labels.registry_start_date={'null' if registry_start_date is None else registry_start_date}",
        f"output_dir={output_dir}/eval",
        f"+training_fraction={training_fraction}",
        "rarity.mode=synthetic",
    ]
    if eligibility_path:
        ev_overrides.append(f"paths.eligibility={eligibility_path}")
    if competing_outcome_path:
        ev_overrides.append(f"paths.competing_outcome={competing_outcome_path}")
    if population_path:
        ev_overrides.append(f"paths.population={population_path}")
    if cohort_fine_col and cohort_fine_value:
        ev_overrides.extend(
            [
                f"cohort_fine_col={cohort_fine_col}",
                f"cohort_fine_value={cohort_fine_value}",
            ]
        )
    if baseline_model:
        ev_overrides.append(f"rarity.baseline_model={baseline_model}")
    for key, value in (rarity_metadata or {}).items():
        ev_overrides.append(f"rarity.size_metadata.{key}={value}")
    ev_cmd = [sys.executable, "-m", "opera.run.evaluate"] + ev_overrides
    result = subprocess.run(ev_cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"    Evaluate failed:\n{result.stderr[-500:]}")
        return {}

    metrics_path = output_dir / "eval" / "metrics.json"
    if metrics_path.exists():
        with open(metrics_path) as f:
            return json.load(f)
    return {}


def parse_tasks(args) -> List[Tuple[str, str]]:
    if args.tasks:
        return [parse_task_ref(item) for item in args.tasks.split(",")]
    if args.cohort and args.outcome:
        return [(args.cohort, args.outcome)]
    raise ValueError("Provide either --tasks or both --cohort and --outcome.")


def aggregate_task_results(all_task_results: Dict[str, Dict[str, Dict[float, list]]]):
    nested_summary = {}
    rows = []
    for task_key, task_results in all_task_results.items():
        cohort, outcome = task_key.split(":", 1)
        nested_summary[task_key] = {}
        for variant_name, frac_dict in task_results.items():
            nested_summary[task_key][variant_name] = {}
            for frac, aurocs in frac_dict.items():
                vals = [v for v in aurocs if not np.isnan(v)]
                if not vals:
                    continue
                ci = np.percentile(vals, [2.5, 97.5])
                agg = {
                    "mean": float(np.mean(vals)),
                    "lower": float(ci[0]),
                    "upper": float(ci[1]),
                    "std": float(np.std(vals)),
                    "n": len(vals),
                }
                nested_summary[task_key][variant_name][float(frac)] = agg
                rows.append(
                    {
                        "task": task_key,
                        "cohort": cohort,
                        "outcome": outcome,
                        "model_family": variant_name,
                        "training_fraction": frac,
                        **agg,
                    }
                )

    task_df = pd.DataFrame(rows)
    if len(task_df) == 0:
        return nested_summary, task_df, pd.DataFrame()

    pooled = task_df.groupby(["model_family", "training_fraction"], as_index=False).agg(
        median_auroc=("mean", "median"),
        lower=("mean", lambda x: float(np.percentile(x, 2.5))),
        upper=("mean", lambda x: float(np.percentile(x, 97.5))),
        n_tasks=("task", "nunique"),
    )
    return nested_summary, task_df, pooled


def compute_baseline_delta_tables(
    task_df: pd.DataFrame,
    baseline_model: Optional[str],
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Compute per-task and pooled label-efficiency gains over a baseline model.

    The headroom-normalized delta is `(model - baseline) / (1 - baseline)`, so
    gains at high baseline AUROC are not overstated.
    """
    if task_df.empty or not baseline_model:
        return pd.DataFrame(), pd.DataFrame()

    baseline = task_df[task_df["model_family"] == baseline_model][
        ["task", "training_fraction", "mean"]
    ].rename(columns={"mean": "baseline_mean"})
    if baseline.empty:
        return pd.DataFrame(), pd.DataFrame()

    merged = task_df.merge(
        baseline,
        on=["task", "training_fraction"],
        how="inner",
    )
    merged = merged[merged["model_family"] != baseline_model].copy()
    if merged.empty:
        return pd.DataFrame(), pd.DataFrame()

    denom = (1.0 - merged["baseline_mean"]).replace(0, np.nan)
    merged["delta_auroc"] = merged["mean"] - merged["baseline_mean"]
    merged["headroom_normalized_delta"] = merged["delta_auroc"] / denom

    pooled = merged.groupby(["model_family", "training_fraction"], as_index=False).agg(
        median_delta_auroc=("delta_auroc", "median"),
        lower_delta_auroc=("delta_auroc", lambda x: float(np.percentile(x, 2.5))),
        upper_delta_auroc=("delta_auroc", lambda x: float(np.percentile(x, 97.5))),
        median_headroom_normalized_delta=(
            "headroom_normalized_delta",
            "median",
        ),
        n_tasks=("task", "nunique"),
    )
    return merged, pooled


def build_tabular_fraction_cmd(
    features_path: str,
    outcome_parquet: str,
    output_dir: Path,
    cohort: str,
    outcome_name: str,
    seed: int,
    models: str = "xgboost",
    tune: bool = False,
    tune_split: str = "tuning",
    n_hours_start_include: int = 1,
    n_hours_end_include: Optional[int] = None,
    eligibility_path: Optional[str] = None,
    competing_outcome_path: Optional[str] = None,
    registry_start_date: Optional[str] = None,
    population_path: Optional[str] = None,
    cohort_fine_col: Optional[str] = None,
    cohort_fine_value: Optional[str] = None,
    categorical_columns: Optional[str] = None,
    model_prefix: Optional[str] = None,
) -> List[str]:
    """Build the subprocess command for training tabular baselines at one fraction.

    Returns the ``sys.argv``-style command list (first element is the Python
    interpreter path) without executing it.  Callers may inspect or run it.

    Parameters
    ----------
    features_path:
        Path to the tabular feature CSV/parquet.
    outcome_parquet:
        Path to the (already-subsampled) outcome parquet for this fraction/seed.
    output_dir:
        Directory where predictions and metadata will be written.
    cohort, outcome_name:
        Labels forwarded to ``train_tabular_baselines``.
    seed:
        Seed used for this fraction/seed cell — ensures reproducibility matches
        the corresponding encoder finetuning run.
    models:
        Comma-separated model names (default ``"xgboost"``).
    tune:
        If ``True``, pass ``--tune`` to enable validation-based HP selection.
    tune_split:
        Forwarded to ``--tune_split`` when *tune* is ``True``.
    n_hours_start_include, n_hours_end_include:
        Horizon window forwarded verbatim (same as the encoder finetune).
    """
    cmd = [
        sys.executable,
        "-m",
        "opera.run.train_tabular_baselines",
        "--features",
        str(features_path),
        "--outcome",
        str(outcome_parquet),
        "--output_dir",
        str(output_dir),
        "--cohort",
        cohort,
        "--outcome_name",
        outcome_name,
        "--models",
        models,
        "--seed",
        str(seed),
        "--n_hours_start_include",
        str(n_hours_start_include),
    ]
    if n_hours_end_include is not None:
        cmd += ["--n_hours_end_include", str(n_hours_end_include)]
    if eligibility_path:
        cmd += ["--eligibility", str(eligibility_path)]
    if competing_outcome_path:
        cmd += ["--competing_outcome", str(competing_outcome_path)]
    if registry_start_date is not None:
        cmd += ["--registry_start_date", str(registry_start_date)]
    if population_path:
        cmd += ["--population", str(population_path)]
    if cohort_fine_col and cohort_fine_value:
        cmd += [
            "--cohort_fine_col",
            str(cohort_fine_col),
            "--cohort_fine_value",
            str(cohort_fine_value),
        ]
    if categorical_columns:
        cmd += ["--categorical_columns", str(categorical_columns)]
    if model_prefix:
        cmd += ["--model_prefix", str(model_prefix)]
    if tune:
        cmd += ["--tune", "--tune_split", tune_split]
    return cmd


def _plot_summary_curves(summary: Dict[str, Dict[str, Dict]], save_path: Path) -> None:
    from opera.visualization.comparison_plots import plot_label_efficiency

    plot_label_efficiency(summary, save_path=str(save_path))


def _pooled_summary_for_plot(
    pooled_df: pd.DataFrame,
) -> Dict[str, Dict[float, Dict[str, float]]]:
    summary: Dict[str, Dict[float, Dict[str, float]]] = {}
    for _, row in pooled_df.iterrows():
        summary.setdefault(row["model_family"], {})[float(row["training_fraction"])] = {
            "mean": float(row["median_auroc"]),
            "lower": float(row["lower"]),
            "upper": float(row["upper"]),
        }
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sweep_config", required=True)
    parser.add_argument("--cohort")
    parser.add_argument("--outcome")
    parser.add_argument("--tasks", help="Comma-separated cohort:outcome pairs.")
    parser.add_argument("--output_dir", default="./results/label_efficiency")
    parser.add_argument("--fractions", default="0.01,0.02,0.05,0.1,0.25,0.5,1.0")
    parser.add_argument("--seeds", default="42,43,44")
    parser.add_argument(
        "--baseline_model",
        help="Model variant used for label-efficiency delta summaries. Defaults to the first variant.",
    )
    parser.add_argument(
        "--plot_tasks",
        help="Optional comma-separated task keys to plot as secondary panels.",
    )
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument(
        "--tabular_features",
        default=None,
        help=(
            "Path to the tabular feature CSV/parquet. When provided, tabular "
            "baselines are retrained at each encoder fraction/seed cell so "
            "learning curves are directly comparable."
        ),
    )
    parser.add_argument(
        "--tabular_models",
        default="xgboost",
        help="Comma-separated tabular model names to train at matched fractions.",
    )
    parser.add_argument(
        "--tabular_tune",
        action="store_true",
        help="Enable validation-based HP tuning for tabular baselines.",
    )
    parser.add_argument(
        "--tabular_categorical_columns",
        default="",
        help="Categorical columns forwarded to matched tabular baselines.",
    )
    args = parser.parse_args()

    cfg = OmegaConf.to_container(OmegaConf.load(args.sweep_config), resolve=True)

    tasks = parse_tasks(args)
    outcomes_cfg = normalize_outcome_config(cfg["outcomes"])
    fractions = [float(x) for x in args.fractions.split(",")]
    seeds = [int(x) for x in args.seeds.split(",")]
    variants = {
        name: variant
        for name, variant in cfg["model_variants"].items()
        if "encoder_ckpt" in variant
    }
    baseline_model = args.baseline_model or next(iter(variants), None)
    all_task_results: Dict[str, Dict[str, Dict[float, list]]] = {}

    for cohort, outcome in tasks:
        task_key = f"{cohort}:{outcome}"
        cohort_cfg = cfg["cohorts"][cohort]
        data_dir = cohort_cfg["data_dir"]
        population_path = cohort_cfg.get("population_file")
        cohort_fine_col = cohort_cfg.get("cohort_fine_col")
        cohort_fine_value = cohort_cfg.get("cohort_fine_value")
        target_subject_ids = population_subject_ids(
            population_path,
            cohort_fine_col=cohort_fine_col,
            cohort_fine_value=cohort_fine_value,
        )
        outcome_cfg = outcomes_cfg.get(outcome, {"outcome_file": f"{outcome}.parquet"})
        registry_start_date = resolve_registry_start_date(cohort_cfg, outcome_cfg)
        outcome_path = outcome_file_path(data_dir, outcome, outcome_cfg)
        eligibility = eligibility_file_path(
            data_dir,
            cohort,
            outcome,
            outcome_cfg,
        )
        eligibility = str(eligibility) if eligibility is not None else None
        competing_path = competing_outcome_file_path(data_dir, outcome_cfg)
        task_output_dir = Path(args.output_dir) / cohort / outcome
        task_results: Dict[str, Dict[float, list]] = {name: {} for name in variants}

        print(f"\n=== Task {task_key} ===")
        for variant_name, variant_cfg in variants.items():
            print(f"\n-- {variant_name} --")
            for frac in fractions:
                print(f"  fraction={frac:.0%}")
                seed_aurocs = []
                for seed in seeds:
                    frac_dir = f"frac{frac:.2f}"
                    cell_dir = task_output_dir / variant_name / frac_dir / f"seed{seed}"
                    metrics_path = cell_dir / "eval" / "metrics.json"

                    cached = metrics_path.exists() and not args.overwrite
                    if cached:
                        with open(metrics_path) as f:
                            metrics = json.load(f)
                        subsampled_path = str(cell_dir / "outcomes_subsampled.parquet")
                    else:
                        subsampled_path = str(cell_dir / "outcomes_subsampled.parquet")
                        subsample_outcome_parquet(
                            outcome_path,
                            frac,
                            seed,
                            subsampled_path,
                            n_hours_start_include=outcome_cfg.get(
                                "n_hours_start_include",
                                1,
                            ),
                            n_hours_end_include=outcome_cfg.get(
                                "n_hours_end_include",
                            ),
                            registry_start_date=registry_start_date,
                            cohort=cohort,
                            outcome_name=outcome,
                            eligibility_path=eligibility,
                            competing_outcome_path=competing_path,
                            target_subject_ids=target_subject_ids,
                        )
                        metrics = run_finetune_and_evaluate(
                            encoder_ckpt=variant_cfg["encoder_ckpt"],
                            encoder_source=variant_cfg["encoder_source"],
                            cohort=cohort,
                            outcome_name=outcome,
                            cohort_data_dir=data_dir,
                            outcome_parquet=subsampled_path,
                            output_dir=cell_dir,
                            training_fraction=frac,
                            rarity_metadata=outcome_split_size_metadata(
                                subsampled_path,
                                registry_start_date=registry_start_date,
                                cohort=cohort,
                                outcome_name=outcome,
                                eligibility_path=eligibility,
                                competing_outcome_path=competing_path,
                                n_hours_start_include=outcome_cfg.get(
                                    "n_hours_start_include", 1
                                ),
                                n_hours_end_include=outcome_cfg.get(
                                    "n_hours_end_include"
                                ),
                                allowed_subject_ids=target_subject_ids,
                            ),
                            baseline_model=baseline_model,
                            base_config=cfg.get(
                                "finetune_base_config",
                                "opera/configs/finetune.yaml",
                            ),
                            registry_start_date=registry_start_date,
                            eligibility_path=eligibility,
                            competing_outcome_path=competing_path,
                            population_path=population_path,
                            cohort_fine_col=cohort_fine_col,
                            cohort_fine_value=cohort_fine_value,
                            pooled_training=(
                                variant_cfg.get("training_population", "local")
                                == "pooled"
                            ),
                            seed=seed,
                            variant_overrides=variant_cfg.get("extra_overrides", []),
                            training_mode=variant_cfg.get("training_mode"),
                        )

                    auroc = metrics.get("discrimination", {}).get("auroc", float("nan"))
                    seed_aurocs.append(auroc)
                    print(f"    seed={seed}: AUROC={auroc:.3f}")

                    # Matched-fraction tabular baseline retraining.
                    # Uses the same subsampled outcome parquet and seed so the
                    # tabular learning curve is directly comparable to the encoder.
                    # Skipped for cached encoder runs (tabular output already exists).
                    if args.tabular_features and not cached:
                        tab_out = cell_dir / "tabular_baselines"
                        tab_cmd = build_tabular_fraction_cmd(
                            features_path=args.tabular_features,
                            outcome_parquet=subsampled_path,
                            output_dir=tab_out,
                            cohort=cohort,
                            outcome_name=outcome,
                            seed=seed,
                            models=args.tabular_models,
                            tune=args.tabular_tune,
                            n_hours_start_include=outcome_cfg.get(
                                "n_hours_start_include", 1
                            ),
                            n_hours_end_include=outcome_cfg.get("n_hours_end_include"),
                            eligibility_path=eligibility,
                            competing_outcome_path=competing_path,
                            registry_start_date=registry_start_date,
                            population_path=population_path,
                            cohort_fine_col=(
                                None
                                if variant_cfg.get("training_population", "local")
                                == "pooled"
                                else cohort_fine_col
                            ),
                            cohort_fine_value=(
                                None
                                if variant_cfg.get("training_population", "local")
                                == "pooled"
                                else cohort_fine_value
                            ),
                            categorical_columns=args.tabular_categorical_columns,
                            model_prefix=(
                                "tabular_pooled"
                                if variant_cfg.get("training_population", "local")
                                == "pooled"
                                else "tabular_local"
                            ),
                        )
                        tab_result = subprocess.run(
                            tab_cmd, capture_output=True, text=True
                        )
                        if tab_result.returncode != 0:
                            print(
                                f"    Tabular baseline failed:\n"
                                f"{tab_result.stderr[-300:]}"
                            )

                task_results[variant_name][frac] = seed_aurocs

        all_task_results[task_key] = task_results

    nested_summary, task_df, pooled_df = aggregate_task_results(all_task_results)
    delta_df, pooled_delta_df = compute_baseline_delta_tables(task_df, baseline_model)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    with open(output_dir / "label_efficiency_results.json", "w") as f:
        json.dump(
            {
                "tasks": nested_summary,
                "pooled_median": pooled_df.to_dict(orient="records"),
                "baseline_model": baseline_model,
                "pooled_delta": pooled_delta_df.to_dict(orient="records"),
            },
            f,
            indent=2,
        )
    task_df.to_csv(output_dir / "label_efficiency_summary.csv", index=False)
    pooled_df.to_csv(output_dir / "label_efficiency_pooled.csv", index=False)
    delta_df.to_csv(output_dir / "label_efficiency_delta.csv", index=False)
    pooled_delta_df.to_csv(
        output_dir / "label_efficiency_pooled_delta.csv",
        index=False,
    )
    print(f"\nResults saved to {output_dir / 'label_efficiency_results.json'}")

    try:
        pooled_summary = _pooled_summary_for_plot(pooled_df)
        _plot_summary_curves(pooled_summary, output_dir / "label_efficiency_pooled.png")

        selected_tasks = (
            args.plot_tasks.split(",")
            if args.plot_tasks
            else list(nested_summary.keys())[:4]
        )
        task_plot_dir = output_dir / "task_plots"
        task_plot_dir.mkdir(exist_ok=True)
        for task_key in selected_tasks:
            if task_key in nested_summary:
                safe_task_key = task_key.replace(":", "__")
                _plot_summary_curves(
                    nested_summary[task_key],
                    task_plot_dir / f"{safe_task_key}.png",
                )
        print(f"Main plot saved to {output_dir / 'label_efficiency_pooled.png'}")
    except Exception as exc:
        print(f"Plotting failed: {exc}")


if __name__ == "__main__":
    main()
