"""
OPERA contrastive learning stage.

Loads a DAPT (or base pretrained) checkpoint, wraps the encoder in the
contrastive model, and trains the multi-outcome SupCon objective.

Usage:
    python -m opera.run.contrastive \
        dapt_ckpt=/path/to/dapt/best.ckpt \
        dataset=hematology_cohort
"""

import hydra
import lightning as L
import torch
from dotenv import load_dotenv
from omegaconf import DictConfig, OmegaConf
from lightning.pytorch.loggers import CSVLogger
from lightning.pytorch.callbacks import ModelCheckpoint

from bonsai.functional.pathing import get_experiment_output_path
from bonsai.functional.checkpointing import (
    extract_encoder_state_dict,
    get_saved_encoder_config,
    save_checkpoint_metadata_sidecar,
)
from bonsai.functional.input_contract import (
    input_contract_metadata,
    resolve_numeric_value_control,
)
from bonsai.functional.checkpointing import (
    mark_training_complete,
    should_skip_completed_training,
)
from opera.compat.bonsai import build_bonsai_encoder, encoder_hparams
from opera.modules.networks.opera_nets import OperaContrastiveModel
from opera.modules.networks.outcome_scaling import resolve_outcome_reference_scales
from opera.modules.networks.competing_risk import (
    validate_competing_risk_sampling,
)
from opera.modules.lightningmodules.OperaContrastiveModule import OperaContrastiveModule
from opera.modules.datamodules.ContrastiveDataModule import (
    ContrastiveDataModule,
    compute_event_time_probability_grids,
)

load_dotenv()


@hydra.main(
    config_path="../configs",
    config_name="contrastive",
    version_base="1.2",
)
def main(cfg: DictConfig) -> None:
    logger = CSVLogger(get_experiment_output_path(), name="contrastive_runs")
    model_save_dir = get_experiment_output_path()
    if should_skip_completed_training(model_save_dir, cfg):
        return

    # ── Load encoder from DAPT checkpoint ────────────────────────────
    ckpt = torch.load(cfg.dapt_ckpt, map_location="cpu", weights_only=False)
    pretrain_hparams = ckpt["hyper_parameters"]
    numeric_value_control = resolve_numeric_value_control(
        cfg.training.get("numeric_value_control", "inherit"), pretrain_hparams
    )

    vocab = torch.load(cfg.paths.vocabulary)

    model_cfg = get_saved_encoder_config(pretrain_hparams)
    encoder = build_bonsai_encoder(model_cfg, vocab_size=len(vocab))

    # Extract and load encoder weights from the checkpoint
    encoder_state = extract_encoder_state_dict(ckpt["state_dict"])
    encoder.load_state_dict(encoder_state, strict=True)

    # ── Outcome names ────────────────────────────────────────────────
    outcome_configs = OmegaConf.to_container(cfg.outcomes, resolve=True)
    outcome_names = sorted(outcome_configs.keys())
    validate_competing_risk_sampling(
        OmegaConf.to_container(cfg.get("competing_risk", {}), resolve=True),
        OmegaConf.to_container(
            cfg.training.get("batch_sampling", {}),
            resolve=True,
        ),
    )
    outcome_sorted_event_times, outcome_event_time_probs = (
        compute_event_time_probability_grids(
            outcome_configs,
            split="train",
        )
    )
    print(
        f"KM event-time grids computed for {len(outcome_sorted_event_times)} outcomes."
    )
    for name, t in outcome_sorted_event_times.items():
        print(f"  {name}: {len(t)} KM-weighted training event locations")

    dapt_embedding_store = None
    if cfg.get("dapt_embedding_store") is not None:
        print(f"Loading DAPT embedding store from {cfg.dapt_embedding_store} ...")
        dapt_embedding_store = torch.load(cfg.dapt_embedding_store, map_location="cpu")
        print(f"  Loaded {len(dapt_embedding_store)} patient embeddings.")
    elif bool(cfg.training.get("require_dapt_embedding_store", False)):
        raise ValueError(
            "training.require_dapt_embedding_store=true but "
            "dapt_embedding_store is null. Build the store before training."
        )

    # ── Build OPERA contrastive model ────────────────────────────────
    model = OperaContrastiveModel(
        encoder=encoder,
        outcome_names=outcome_names,
        hidden_size=model_cfg["hidden_size"],
        projection_hidden_dim=cfg.model.projection_hidden_dim,
        projection_dim=cfg.model.projection_dim,
        temperature=cfg.model.temperature,
        outcome_sorted_event_times=outcome_sorted_event_times,
        outcome_event_time_probs=outcome_event_time_probs,
        dapt_lambda_floor=cfg.model.get("dapt_lambda_floor", 0.55),
        dapt_anchor_weight=cfg.model.get("dapt_anchor_weight", 0.2),
        competing_event_weight=cfg.model.get("competing_event_weight", 0.0),
        competing_event_handling=cfg.model.get(
            "competing_event_handling", "hard_negative"
        ),
        effective_pair_normalization=cfg.model.get(
            "effective_pair_normalization", True
        ),
        cross_outcome_config=resolve_outcome_reference_scales(
            OmegaConf.to_container(cfg.get("cross_outcome", {}), resolve=True)
        ),
        projection_mode=cfg.model.get("projection_mode", "shared"),
        freeze_encoder=cfg.model.freeze_encoder,
        pooling=cfg.model.pooling,
        dapt_embedding_store=dapt_embedding_store,
        competing_risk_config=OmegaConf.to_container(
            cfg.get("competing_risk", {}),
            resolve=True,
        ),
    )

    # ── Data ─────────────────────────────────────────────────────────
    data_module = ContrastiveDataModule(
        path_train_data=cfg.paths.train_split,
        path_val_data=cfg.paths.val_split,
        path_population=cfg.paths.population,
        outcome_configs=outcome_configs,
        predict_token_id=vocab["[CLS]"],
        batch_size=cfg.training.batch_size,
        num_workers=cfg.hardware.num_workers,
        max_len=encoder_hparams(encoder)["max_seqlen"],
        batch_sampling=cfg.training.get("batch_sampling", {}),
        subject_data_paths=cfg.paths.get("subject_data_paths"),
        numeric_value_control=numeric_value_control,
    )

    # ── Lightning ────────────────────────────────────────────────────
    lightning_module = OperaContrastiveModule(
        model=model,
        outcome_names=outcome_names,
        learning_rate=cfg.training.learning_rate,
        encoder_lr_multiplier=cfg.training.encoder_lr_multiplier,
        optimizer_epsilon=cfg.training.optimizer_epsilon,
        scheduler_warmup_epochs=cfg.training.scheduler_warmup_epochs,
        dapt_anchor_weight=cfg.model.get("dapt_anchor_weight", 0.2),
        checkpoint_metadata={
            "training_stage": "opera_contrastive_adaptation",
            "source_checkpoint": cfg.dapt_ckpt,
            "dataset": cfg.dataset,
            "outcome_set": outcome_names,
            **input_contract_metadata(numeric_value_control),
        },
    )

    ckpt_callback = ModelCheckpoint(
        dirpath=model_save_dir,
        monitor="val/loss",
        mode="min",
        save_top_k=1,
        filename="best",
        enable_version_counter=False,
        save_last=True,
    )

    trainer = L.Trainer(
        accelerator=cfg.hardware.accelerator,
        accumulate_grad_batches=cfg.training.accumulate_grad_batches,
        devices=cfg.hardware.num_devices,
        limit_val_batches=cfg.training.limit_val_batches,
        limit_train_batches=cfg.training.limit_train_batches,
        callbacks=[ckpt_callback],
        logger=[logger],
        max_epochs=cfg.training.epochs,
        num_nodes=cfg.hardware.num_nodes,
        precision=cfg.hardware.precision,
    )

    trainer.fit(model=lightning_module, datamodule=data_module)
    save_checkpoint_metadata_sidecar(model_save_dir, lightning_module)
    mark_training_complete(model_save_dir, cfg)


if __name__ == "__main__":
    main()
