"""DALY-CARE-only pretraining entry point.

This wraps the BONSAI pretraining machinery with an OPERA-owned config so the
paper ladder can include a clean DALY-CARE-from-scratch checkpoint without
editing the shared BONSAI config tree.
"""

import hydra
import lightning as L
from dotenv import load_dotenv
from hydra.utils import get_class
from lightning.pytorch.callbacks import ModelCheckpoint
from lightning.pytorch.loggers import CSVLogger
from omegaconf import DictConfig

from bonsai.functional.checkpointing import (
    CompletedEpochCheckpoint,
    save_checkpoint_metadata_sidecar,
)
from bonsai.functional.checkpointing import (
    mark_training_complete,
    should_skip_completed_training,
)
from bonsai.functional.model_config import validate_pretraining_attention
from bonsai.functional.input_contract import input_contract_metadata
from bonsai.functional.pathing import get_experiment_output_path
from bonsai.modules.datamodules.PretrainDataModule import PretrainDataModule
from bonsai.modules.lightningmodules.PretrainModule import PretrainModule
from opera.compat.bonsai import build_bonsai_pretrain

load_dotenv()


@hydra.main(
    config_path="../configs",
    config_name="daly_care_pretrain",
    version_base="1.2",
)
def main(cfg: DictConfig) -> None:
    logger = CSVLogger(get_experiment_output_path(), name="training_runs")
    model_save_dir = get_experiment_output_path()
    if should_skip_completed_training(model_save_dir, cfg):
        return

    dataset_class = get_class(cfg.paths.dataset_class)
    validate_pretraining_attention(dataset_class, causal=cfg.model.causal)
    data_module = PretrainDataModule(
        path_train_data=cfg.paths.train_split,
        path_val_data=cfg.paths.val_split,
        path_vocab=cfg.paths.vocab,
        path_population=cfg.paths.population,
        batch_size=cfg.training.batch_size,
        num_workers=cfg.hardware.num_workers,
        dataset_class=dataset_class,
        masking_config=cfg.training.get("masking"),
        cutoff_date=cfg.training.get("cutoff_date"),
        max_len=cfg.training.max_len,
        train_truncation_strategy=cfg.training.get("truncation_strategy", "tail"),
        val_truncation_strategy=cfg.training.get(
            "validation_truncation_strategy", "tail"
        ),
        tail_window_probability=cfg.training.get("tail_window_probability", 1.0),
        value_embedding_mode=cfg.model.get("value_embedding_mode", "legacy"),
        numeric_value_control=cfg.training.get("numeric_value_control", "observed"),
    )

    model = build_bonsai_pretrain(
        cfg.model,
        vocab_size=len(data_module.vocabulary),
    )

    ckpt_callback = ModelCheckpoint(
        dirpath=model_save_dir,
        monitor="val/loss",
        mode="min",
        save_top_k=1,
        filename="best",
        enable_version_counter=False,
        save_last=True,
    )

    lightning_module = PretrainModule(
        model=model,
        compile_mode=cfg.hardware.compile_mode,
        learning_rate=cfg.training.learning_rate,
        optimizer_epsilon=cfg.training.optimizer_epsilon,
        scheduler_warmup_epochs=cfg.training.scheduler_warmup_epochs,
        value_regression_loss_weight=cfg.training.get(
            "value_regression_loss_weight", 1.0
        ),
        checkpoint_metadata={
            "training_stage": cfg.get("training_stage", "daly_care_only_pretraining"),
            "dataset": cfg.get("dataset"),
            "tokenizer_vocab_path": cfg.paths.vocab,
            "split_identifier": "train:tuning",
            "pretraining_scope": "daly_care_only",
            **input_contract_metadata(
                cfg.training.get("numeric_value_control", "observed")
            ),
        },
    )

    callbacks = [ckpt_callback]
    milestones = list(cfg.training.get("checkpoint_milestone_epochs", []))
    if any(int(epoch) >= int(cfg.training.epochs) for epoch in milestones):
        raise ValueError(
            "checkpoint_milestone_epochs must be earlier than training.epochs; "
            "last.ckpt already preserves the final epoch."
        )
    if milestones:
        callbacks.append(CompletedEpochCheckpoint(model_save_dir, milestones))

    trainer = L.Trainer(
        accelerator=cfg.hardware.accelerator,
        accumulate_grad_batches=cfg.training.accumulate_grad_batches,
        devices=cfg.hardware.num_devices,
        limit_val_batches=cfg.training.limit_val_batches,
        limit_train_batches=cfg.training.limit_train_batches,
        callbacks=callbacks,
        logger=[logger],
        max_epochs=cfg.training.epochs,
        num_nodes=cfg.hardware.num_nodes,
        precision=cfg.hardware.precision,
    )

    trainer.fit(
        model=lightning_module,
        datamodule=data_module,
        ckpt_path=cfg.paths.ckpt_path,
    )
    save_checkpoint_metadata_sidecar(
        model_save_dir,
        lightning_module,
        extra={
            "completed_epochs": int(trainer.current_epoch) + 1,
            "optimizer_steps": int(trainer.global_step),
            "training_examples_seen": int(
                lightning_module.training_examples_seen.item()
            ),
            "training_tokens_seen": int(lightning_module.training_tokens_seen.item()),
            "checkpoint_milestone_epochs": [int(value) for value in milestones],
        },
    )
    mark_training_complete(model_save_dir, cfg)


if __name__ == "__main__":
    main()
